# app/middleware/superhuman_security.py
# ======================================================================================
# ==        SUPERHUMAN SECURITY MIDDLEWARE (v1.0 - INTEGRATION EDITION)             ==
# ======================================================================================
"""
وسيط الأمان الخارق - Superhuman Security Middleware

Integrates all security components into Flask:
- WAF (Web Application Firewall)
- Adaptive Rate Limiting
- Zero Trust Authentication
- AI Threat Detection
- Telemetry & Analytics
"""

import time
from collections.abc import Callable
from functools import wraps
from typing import Any

from flask import Flask, g, jsonify, request

from app.analysis.anomaly_detector import AnomalyDetector
from app.analysis.pattern_recognizer import PatternRecognizer
from app.security.rate_limiter import AdaptiveRateLimiter, UserTier
from app.security.threat_detector import AIThreatDetector
from app.security.waf import WebApplicationFirewall
from app.security.zero_trust import ZeroTrustAuthenticator
from app.telemetry.events import EventTracker
from app.telemetry.logging import StructuredLogger
from app.telemetry.metrics import MetricsCollector
from app.telemetry.tracing import DistributedTracer


class SuperhumanSecurityMiddleware:
    """
    وسيط الأمان الخارق - Superhuman Security Middleware

    Integrates all security and telemetry components
    Better than any single commercial solution
    """

    def __init__(
        self,
        app: Flask | None = None,
        secret_key: str | None = None,
        enable_waf: bool = True,
        enable_rate_limiting: bool = True,
        enable_zero_trust: bool = True,
        enable_ai_detection: bool = True,
        enable_telemetry: bool = True,
        enable_analytics: bool = True,
    ):
        # Initialize components
        self.waf = WebApplicationFirewall() if enable_waf else None
        self.rate_limiter = AdaptiveRateLimiter() if enable_rate_limiting else None
        self.zero_trust = (
            ZeroTrustAuthenticator(secret_key or "change-me-in-production")
            if enable_zero_trust
            else None
        )
        self.ai_detector = AIThreatDetector() if enable_ai_detection else None

        # Telemetry components
        self.tracer = DistributedTracer() if enable_telemetry else None
        self.metrics = MetricsCollector() if enable_telemetry else None
        self.logger = StructuredLogger() if enable_telemetry else None
        self.events = EventTracker() if enable_telemetry else None

        # Analytics components
        self.anomaly_detector = AnomalyDetector() if enable_analytics else None
        self.pattern_recognizer = PatternRecognizer() if enable_analytics else None

        # Configuration
        self.enabled_features = {
            "waf": enable_waf,
            "rate_limiting": enable_rate_limiting,
            "zero_trust": enable_zero_trust,
            "ai_detection": enable_ai_detection,
            "telemetry": enable_telemetry,
            "analytics": enable_analytics,
        }

        if app:
            self.init_app(app)

    def init_app(self, app: Flask):
        """Initialize middleware with Flask app"""

        # Register before_request handler
        @app.before_request
        def before_request():
            return self.process_request()

        # Register after_request handler
        @app.after_request
        def after_request(response):
            return self.process_response(response)

        # Register error handler
        @app.errorhandler(403)
        def handle_forbidden(error):
            return (
                jsonify(
                    {"error": "Access Forbidden", "message": "Security check failed", "code": 403}
                ),
                403,
            )

        # Register error handler for rate limiting
        @app.errorhandler(429)
        def handle_rate_limit(error):
            return (
                jsonify(
                    {"error": "Too Many Requests", "message": "Rate limit exceeded", "code": 429}
                ),
                429,
            )

        # Add stats endpoint
        @app.route("/api/security/stats")
        def security_stats():
            return jsonify(self.get_statistics())

    def process_request(self):
        """Process incoming request through security layers"""
        # Start telemetry
        if self.tracer:
            trace_id, span_id = self.tracer.start_trace(
                f"{request.method} {request.path}",
                attributes={
                    "http.method": request.method,
                    "http.url": request.url,
                    "http.user_agent": request.headers.get("User-Agent", ""),
                },
            )
            g.trace_id = trace_id
            g.span_id = span_id
            g.request_start_time = time.time()

        # Get IP address
        ip_address = request.remote_addr or "unknown"

        # Layer 1: Web Application Firewall
        if self.waf:
            is_safe, attack = self.waf.check_request(request)
            if not is_safe:
                # Log security event
                if self.events:
                    self.events.track_security_event(
                        name="waf_block",
                        severity="high",
                        properties={
                            "ip": ip_address,
                            "attack_type": attack.attack_type if attack else "unknown",
                            "endpoint": request.path,
                        },
                    )

                # Record metric
                if self.metrics:
                    self.metrics.inc_counter("security_threats_detected", labels={"type": "waf"})

                # End span with error
                if self.tracer and hasattr(g, "span_id"):
                    self.tracer.end_span(
                        g.span_id, status="error", status_message="WAF blocked request"
                    )

                return (
                    jsonify(
                        {
                            "error": "Security Violation",
                            "message": "Request blocked by WAF",
                            "code": 403,
                        }
                    ),
                    403,
                )

        # Layer 2: AI Threat Detection
        if self.ai_detector:
            threat_score, detection = self.ai_detector.analyze_request(request, ip_address)

            if detection and detection.severity == "critical":
                # Log security event
                if self.events:
                    self.events.track_security_event(
                        name="ai_threat_detected",
                        severity="critical",
                        properties={
                            "ip": ip_address,
                            "threat_score": threat_score,
                            "threat_type": detection.threat_type,
                        },
                    )

                # Record metric
                if self.metrics:
                    self.metrics.inc_counter("security_threats_detected", labels={"type": "ai"})
