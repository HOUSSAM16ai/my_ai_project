# app/services/system_service.py
#
# =====================================================================================
# ==                        NEURAL SUBSTRATE OMNISCIENT SYSTEM                      ==
# ==                   “Akasha+” – The Sentient Nervous Lattice (v11.0.0)            ==
# =====================================================================================
#
# PRIME DIRECTIVE:
#   This module is the sanctified membrane through which the Agent perceives
#   (filesystem + git) and inscribes memory (database + vectors). It is PURE:
#   - No business logic
#   - No LLM prompting
#   - Only perception, hashing, indexing, context retrieval, and truth.
#
# DESIGN PILLARS:
#   1. Deterministic Contracts: All public functions return ToolResult
#   2. Path Sanctity: Hardened resolution + anti-traversal + symlink validation
#   3. Incremental Vector Memory: Hash-based delta indexing + chunk-level granularity
#   4. Architectural Prioritization: app/services/* boosted during similarity retrieval
#   5. Observability: meta fields (elapsed_ms, cache_hit, chunk_count, error_code)
#   6. Safety: Size caps, binary detection, controlled extensions
#   7. Extensibility: Clear TODO anchors for future modularization
#
# NOTE:
#   Epic commentary is removable with zero functional impact.
#
from __future__ import annotations

import hashlib
import logging
import mimetypes
import os
import subprocess
import threading
import time
from collections import OrderedDict
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

from flask import current_app
from sqlalchemy import text
from sqlalchemy.exc import OperationalError, SQLAlchemyError

from app import db


# ---------------------------------------------------------------------------
# ToolResult (يفضل نقله لاحقاً إلى shared/contracts.py لتفادي التبعيات الدائرية)
# ---------------------------------------------------------------------------
@dataclass
class ToolResult:
    ok: bool
    data: Any = None
    error: str | None = None
    meta: dict[str, Any] | None = None

    def to_dict(self):
        return asdict(self)


__version__ = "11.0.0"

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# CONFIG (قابلة للتهيئة عبر متغيرات بيئة)
# ---------------------------------------------------------------------------
PROJECT_ROOT = Path(os.getenv("PROJECT_ROOT", Path.cwd())).resolve()
ALLOWED_EXTENSIONS = set(
    filter(
        None,
        os.getenv(
            "SYSTEM_SERVICE_ALLOWED_EXT", ".py,.md,.txt,.json,.yml,.yaml,.js,.ts,.html,.css,.sh"
        ).split(","),
    )
)
IGNORED_DIRS = {
    "__pycache__",
    ".git",
    ".idea",
    "venv",
    ".vscode",
    "migrations",
    "instance",
    "tmp",
    "node_modules",
}
MAX_FILE_BYTES = int(os.getenv("SYSTEM_SERVICE_MAX_FILE_BYTES", "1500000"))  # 1.5MB
CHUNK_SIZE = int(os.getenv("SYSTEM_SERVICE_CHUNK_SIZE", "6000"))
CHUNK_OVERLAP = int(os.getenv("SYSTEM_SERVICE_CHUNK_OVERLAP", "500"))
EMBED_BATCH = int(os.getenv("SYSTEM_SERVICE_EMBED_BATCH", "32"))
ENABLE_FILE_LRU = os.getenv("SYSTEM_SERVICE_FILE_CACHE", "1") == "1"
FILE_LRU_CAPACITY = int(os.getenv("SYSTEM_SERVICE_FILE_CACHE_CAP", "64"))
PRIORITY_PATH_PREFIX = "app/services/"
VECTOR_DIM = 384  # all-MiniLM-L6-v2
EMBED_MODEL_NAME = os.getenv("EMBED_MODEL_NAME", "all-MiniLM-L6-v2")

# ---------------------------------------------------------------------------
# INTERNAL STATE
# ---------------------------------------------------------------------------
_embedding_model = None
_embedding_lock = threading.Lock()

# LRU Cache for small files (path -> dict)
_file_lru: OrderedDict[str, dict[str, Any]] = OrderedDict()


# ---------------------------------------------------------------------------
# UTILITIES
# ---------------------------------------------------------------------------
def _now_ms() -> float:
    return time.perf_counter() * 1000.0


def _hash_text(txt: str) -> str:
    return hashlib.sha256(txt.encode("utf-8", errors="ignore")).hexdigest()


def _is_binary_maybe(path: Path) -> bool:
    # Heuristic: use mimetype or raw sniff
    mime, _ = mimetypes.guess_type(str(path))
    if mime and not mime.startswith("text"):
        return True
    try:
        with path.open("rb") as f:
            block = f.read(512)
        return b"\0" in block
    except Exception:
        return True


def _path_within_project(p: Path) -> bool:
    try:
        p = p.resolve()
        return p == PROJECT_ROOT or PROJECT_ROOT in p.parents
    except Exception:
        return False


def _normalize_rel_path(rel_path: str) -> Path:
    if not rel_path or ".." in rel_path or rel_path.startswith("~"):
        raise ValueError("PATH_TRAVERSAL_DETECTED")
    p = (PROJECT_ROOT / rel_path).resolve()
    if not _path_within_project(p):
        raise ValueError("OUT_OF_PROJECT_BOUNDARY")
    return p


def _format_vector_literal(vec) -> str:
    return "[" + ",".join(f"{x:.6f}" for x in vec) + "]"


# ---------------------------------------------------------------------------
# EMBEDDING MODEL (Lazy load)
# ---------------------------------------------------------------------------
def get_embedding_model():
    global _embedding_model
    if _embedding_model is None:
        with _embedding_lock:
            if _embedding_model is None:
                from sentence_transformers import SentenceTransformer

                current_app.logger.info(
                    f"[embeddings] Loading model '{EMBED_MODEL_NAME}' (one-time)..."
                )
                _embedding_model = SentenceTransformer(EMBED_MODEL_NAME)
    return _embedding_model


# ---------------------------------------------------------------------------
# DB STRUCTURE
# code_documents:
#   id (TEXT PK) -> file_path::chunk_index
#   file_path (TEXT)
#   chunk_index (INT)
#   content (TEXT)
#   file_hash (TEXT)  # entire file hash for chunk 0 duplication
#   chunk_hash (TEXT) # hash of this chunk’s text
#   source (TEXT)
#   embedding (vector(VECTOR_DIM))
#   updated_at (TIMESTAMP)
# ---------------------------------------------------------------------------
def _ensure_code_documents():
    db.session.execute(
        text(
            f"""
        CREATE TABLE IF NOT EXISTS code_documents (
            id TEXT PRIMARY KEY,
            file_path TEXT,
            chunk_index INT,
            content TEXT,
            file_hash TEXT,
            chunk_hash TEXT,
            source TEXT,
            embedding vector({VECTOR_DIM}),
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
    """
        )
