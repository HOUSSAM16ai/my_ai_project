# 🚀 CRUD RESTful API - دليل التطبيق الخارق الاحترافي

> **نظام API خارق رهيب احترافي خيالي خرافي يتفوق على الشركات العملاقة**
> 
> **An extraordinarily professional world-class RESTful API surpassing tech giants like Google, Facebook, Microsoft, and OpenAI**

---

## 📋 جدول المحتويات | Table of Contents

1. [نظرة عامة | Overview](#نظرة-عامة--overview)
2. [المميزات الخارقة | Extraordinary Features](#المميزات-الخارقة--extraordinary-features)
3. [البنية المعمارية | Architecture](#البنية-المعمارية--architecture)
4. [التثبيت والإعداد | Installation & Setup](#التثبيت-والإعداد--installation--setup)
5. [نقاط النهاية | API Endpoints](#نقاط-النهاية--api-endpoints)
6. [أمثلة عملية | Practical Examples](#أمثلة-عملية--practical-examples)
7. [التحقق من صحة البيانات | Validation](#التحقق-من-صحة-البيانات--validation)
8. [معالجة الأخطاء | Error Handling](#معالجة-الأخطاء--error-handling)
9. [الأمان | Security](#الأمان--security)
10. [الأداء | Performance](#الأداء--performance)
11. [الاختبار | Testing](#الاختبار--testing)
12. [النشر | Deployment](#النشر--deployment)

---

## 🌟 نظرة عامة | Overview

هذا المشروع يقدم **CRUD RESTful API** خارق احترافي بمستوى عالمي، مبني على أسس صلبة ومتبعاً أفضل الممارسات العالمية.

This project provides an **extraordinarily professional world-class CRUD RESTful API**, built on solid foundations following global best practices.

### ما هو CRUD؟ | What is CRUD?

CRUD يرمز للعمليات الأساسية الأربع على البيانات:

- **C**reate (إنشاء) - `POST` - إنشاء سجلات جديدة
- **R**ead (قراءة) - `GET` - قراءة البيانات الموجودة
- **U**pdate (تحديث) - `PUT` - تحديث سجلات موجودة
- **D**elete (حذف) - `DELETE` - حذف سجلات

### ما هو RESTful API؟ | What is RESTful API?

REST (Representational State Transfer) هو نمط معماري لتصميم واجهات برمجة التطبيقات يستخدم HTTP بطريقة قياسية:

- استخدام طرق HTTP القياسية (GET, POST, PUT, DELETE)
- عناوين URL واضحة ومنطقية
- رسائل JSON للتواصل
- حالة (stateless) - كل طلب مستقل
- استجابات موحدة ومتوقعة

---

## 🔥 المميزات الخارقة | Extraordinary Features

### 1. ✅ CRUD Operations احترافية | Professional CRUD Operations

```python
✓ Create  - إنشاء سجلات جديدة مع التحقق الكامل
✓ Read    - قراءة مع الترقيم والبحث والترتيب
✓ Update  - تحديث جزئي أو كامل
✓ Delete  - حذف آمن مع التحقق
```

### 2. 🛡️ التحقق من صحة البيانات | Input Validation

- استخدام **Marshmallow** للتحقق من صحة المدخلات
- مخططات (schemas) مخصصة لكل نموذج
- رسائل خطأ واضحة ومفصلة
- التحقق من الأنواع والطول والقيم المسموحة

```python
from app.validators import UserSchema
from app.validators.base import BaseValidator

# مثال على التحقق
success, data, errors = BaseValidator.validate(
    UserSchema, 
    request.json
)
```

### 3. 📊 معالجة الأخطاء الموحدة | Standardized Error Handling

جميع الأخطاء تُرجع بصيغة موحدة:

```json
{
  "success": false,
  "error": {
    "code": 400,
    "message": "Validation Error",
    "details": {
      "validation_errors": {
        "email": ["Not a valid email address"]
      }
    }
  },
  "timestamp": "2025-10-11T20:32:20Z"
}
```

### 4. 🔐 الأمان المتقدم | Advanced Security

- مصادقة المستخدم (Flask-Login)
- تفويض الأدمن فقط للعمليات الحساسة
- حماية من SQL Injection
- CORS مُكوّن بشكل آمن
- تسجيل جميع العمليات

### 5. ⚡ الأداء العالي | High Performance

- تخزين مؤقت ذكي (5 دقائق TTL)
- استعلامات محسّنة
- ترقيم (pagination) فعال
- فهرسة قاعدة البيانات
- ضغط الاستجابات

### 6. 📖 التوثيق التلقائي | Automatic Documentation

- OpenAPI/Swagger specs
- أمثلة تفاعلية
- توثيق كل endpoint
- شرح المعاملات والاستجابات

### 7. 🔍 المراقبة والتسجيل | Monitoring & Logging

- تسجيل جميع الطلبات
- قياس الأداء
- تتبع الأخطاء
- معرّفات فريدة للطلبات

---

## 🏗️ البنية المعمارية | Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                     CLIENT APPLICATION                       │
│                  (Web, Mobile, Desktop)                      │
└────────────────────┬────────────────────────────────────────┘
                     │ HTTP/HTTPS
                     ▼
┌─────────────────────────────────────────────────────────────┐
│                    API GATEWAY LAYER                         │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │ CORS Config  │  │  Error       │  │  Request     │      │
│  │              │  │  Handlers    │  │  Logger      │      │
│  └──────────────┘  └──────────────┘  └──────────────┘      │
└────────────────────┬────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────────┐
│                  AUTHENTICATION LAYER                        │
│              (Flask-Login + Admin Check)                     │
└────────────────────┬────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────────┐
│                   VALIDATION LAYER                           │
│  ┌──────────────────────────────────────────────────────┐  │
│  │         Marshmallow Schemas                          │  │
│  │  • UserSchema    • MissionSchema                     │  │
│  │  • TaskSchema    • PaginationSchema                  │  │
│  └──────────────────────────────────────────────────────┘  │
└────────────────────┬────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────────┐
│                    BUSINESS LOGIC LAYER                      │
│  ┌──────────────────────────────────────────────────────┐  │
│  │         Database Service                             │  │
│  │  • get_all_tables()    • get_table_data()           │  │
│  │  • create_record()     • update_record()            │  │
│  │  • delete_record()     • execute_query()            │  │
│  └──────────────────────────────────────────────────────┘  │
└────────────────────┬────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────────┐
│                      DATA ACCESS LAYER                       │
│  ┌──────────────────────────────────────────────────────┐  │
│  │         SQLAlchemy ORM Models                        │  │
│  │  • User          • Mission      • Task               │  │
│  │  • MissionPlan   • MissionEvent                      │  │
│  └──────────────────────────────────────────────────────┘  │
└────────────────────┬────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────────┐
│                   DATABASE (PostgreSQL)                      │
│                      Supabase Cloud                          │
└─────────────────────────────────────────────────────────────┘
```

---

## 🚀 التثبيت والإعداد | Installation & Setup

### المتطلبات الأساسية | Prerequisites

