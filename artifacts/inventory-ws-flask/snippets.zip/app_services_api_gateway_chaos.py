# app/services/api_gateway_chaos.py
# ======================================================================================
# ==        API GATEWAY CHAOS ENGINEERING (v1.0 - RESILIENCE EDITION)              ==
# ======================================================================================
# PRIME DIRECTIVE:
#   هندسة الفوضى واختبار المتانة - Chaos engineering and resilience testing
#   ✨ المميزات:
#   - Fault injection (latency, errors, timeouts)
#   - Circuit breaker pattern implementation
#   - Bulkheads pattern for resource isolation
#   - Resilience testing and validation
#   - Automated disaster recovery
#   - Chaos experiments management

import random
import threading
import time
from collections import defaultdict, deque
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum
from typing import Any

from flask import current_app

# ======================================================================================
# ENUMERATIONS
# ======================================================================================


class FaultType(Enum):
    """Types of faults to inject"""

    LATENCY = "latency"
    ERROR = "error"
    TIMEOUT = "timeout"
    PARTIAL_FAILURE = "partial_failure"
    NETWORK_PARTITION = "network_partition"
    RESOURCE_EXHAUSTION = "resource_exhaustion"


class CircuitState(Enum):
    """Circuit breaker states"""

    CLOSED = "closed"  # Normal operation
    OPEN = "open"  # Blocking requests
    HALF_OPEN = "half_open"  # Testing recovery


# ======================================================================================
# DATA STRUCTURES
# ======================================================================================


@dataclass
class ChaosExperiment:
    """Chaos experiment configuration"""

    experiment_id: str
    name: str
    description: str
    fault_type: FaultType
    target_service: str
    fault_rate: float  # 0.0 to 1.0
    duration_seconds: int
    started_at: datetime | None = None
    ended_at: datetime | None = None
    metrics: dict[str, Any] = field(default_factory=dict)


@dataclass
class CircuitBreakerConfig:
    """Circuit breaker configuration"""

    failure_threshold: int = 5
    timeout_seconds: int = 60
    half_open_requests: int = 3


@dataclass
class CircuitBreakerState:
    """Circuit breaker state"""

    state: CircuitState = CircuitState.CLOSED
    failure_count: int = 0
    last_failure_time: datetime | None = None
    opened_at: datetime | None = None
    success_count: int = 0


# ======================================================================================
# CHAOS ENGINEERING SERVICE
# ======================================================================================


class ChaosEngineeringService:
    """
    خدمة هندسة الفوضى - Chaos engineering service

    Features:
    - Controlled fault injection
    - Circuit breaker pattern
    - Resilience testing
    - Automated recovery testing
    """

    def __init__(self):
        self.active_experiments: dict[str, ChaosExperiment] = {}
        self.experiment_history: deque = deque(maxlen=1000)
        self.lock = threading.RLock()

    def start_experiment(self, experiment: ChaosExperiment) -> bool:
        """Start a chaos experiment"""
        with self.lock:
            if experiment.experiment_id in self.active_experiments:
                return False

            experiment.started_at = datetime.now(UTC)
            self.active_experiments[experiment.experiment_id] = experiment

            current_app.logger.info(
                f"Started chaos experiment: {experiment.name} ({experiment.fault_type.value})"
            )
            return True

    def stop_experiment(self, experiment_id: str) -> bool:
        """Stop a chaos experiment"""
        with self.lock:
            if experiment_id not in self.active_experiments:
                return False

            experiment = self.active_experiments[experiment_id]
            experiment.ended_at = datetime.now(UTC)

            # Move to history
            self.experiment_history.append(experiment)
            del self.active_experiments[experiment_id]

            current_app.logger.info(f"Stopped chaos experiment: {experiment.name}")
            return True

    def inject_fault(
        self, service_id: str, request_context: dict[str, Any]
    ) -> dict[str, Any] | None:
        """
        Inject fault if experiment is active

        Returns:
            Fault data if injected, None otherwise
        """
        with self.lock:
            for experiment in self.active_experiments.values():
                if experiment.target_service != service_id:
                    continue

                # Check if experiment is still active
                if experiment.started_at:
                    elapsed = (datetime.now(UTC) - experiment.started_at).total_seconds()
                    if elapsed > experiment.duration_seconds:
                        self.stop_experiment(experiment.experiment_id)
                        continue

                # Probabilistic fault injection
                if random.random() < experiment.fault_rate:
                    return self._apply_fault(experiment, request_context)

        return None

    def _apply_fault(
        self, experiment: ChaosExperiment, request_context: dict[str, Any]
    ) -> dict[str, Any]:
        """Apply specific fault type"""
        fault_data = {
            "experiment_id": experiment.experiment_id,
            "fault_type": experiment.fault_type.value,
            "timestamp": datetime.now(UTC).isoformat(),
        }

        if experiment.fault_type == FaultType.LATENCY:
            # Inject latency
            delay_ms = random.randint(100, 5000)
            time.sleep(delay_ms / 1000)
            fault_data["delay_ms"] = delay_ms

        elif experiment.fault_type == FaultType.ERROR:
            # Inject error
            fault_data["error"] = "Chaos experiment induced error"
            fault_data["error_code"] = "CHAOS_ERROR"

        elif experiment.fault_type == FaultType.TIMEOUT:
            # Simulate timeout
            time.sleep(30)  # Long delay
            fault_data["timeout"] = True

        # Update experiment metrics
        experiment.metrics["faults_injected"] = experiment.metrics.get("faults_injected", 0) + 1

        return fault_data

