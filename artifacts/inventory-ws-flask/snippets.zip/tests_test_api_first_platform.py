# tests/test_api_first_platform.py
# =============================================================================
# ==   TESTS FOR API-FIRST PLATFORM SERVICE                                ==
# =============================================================================

import time
from datetime import UTC, datetime

import pytest

from app.services.api_first_platform_service import (
    APIContract,
    APIFirstPlatformService,
    ContractRegistry,
    ContractType,
    IdempotencyStore,
    RateLimitConfig,
    RateLimiter,
    WebhookSigner,
    generate_etag,
)

# =============================================================================
# Contract Management Tests
# =============================================================================


class TestContractManagement:
    """اختبارات إدارة العقود"""

    def test_create_api_contract(self):
        """اختبار إنشاء عقد API"""
        spec = {
            "openapi": "3.1.0",
            "info": {"title": "Test API", "version": "1.0.0"},
            "paths": {"/test": {"get": {"summary": "Test endpoint"}}},
        }

        contract = APIContract(
            name="test-api", type=ContractType.OPENAPI, version="v1", specification=spec
        )

        assert contract.name == "test-api"
        assert contract.type == ContractType.OPENAPI
        assert contract.version == "v1"
        assert contract.checksum is not None
        assert len(contract.checksum) == 64  # SHA256 hex

    def test_contract_checksum_consistency(self):
        """اختبار ثبات checksum"""
        spec = {"test": "data"}

        contract1 = APIContract(
            name="test", type=ContractType.OPENAPI, version="v1", specification=spec
        )

        contract2 = APIContract(
            name="test", type=ContractType.OPENAPI, version="v1", specification=spec
        )

        assert contract1.checksum == contract2.checksum

    def test_contract_registry(self):
        """اختبار سجل العقود"""
        registry = ContractRegistry()

        contract = APIContract(
            name="accounts-api",
            type=ContractType.OPENAPI,
            version="v1",
            specification={"test": "data"},
        )

        registry.register(contract)

        retrieved = registry.get("accounts-api")
        assert retrieved is not None
        assert retrieved.name == "accounts-api"

    def test_breaking_changes_detection(self):
        """اختبار كشف التغييرات المكسّرة"""
        registry = ContractRegistry()

        old_contract = APIContract(
            name="test", type=ContractType.OPENAPI, version="v1", specification={}
        )

        new_contract = APIContract(
            name="test", type=ContractType.OPENAPI, version="v2", specification={}
        )

        breaking_changes = registry.validate_breaking_changes(old_contract, new_contract)

        assert len(breaking_changes) > 0
        assert "Major version change" in breaking_changes[0]


# =============================================================================
# Idempotency Tests
# =============================================================================


class TestIdempotency:
    """اختبارات التماثل"""

    def test_idempotency_store_set_get(self):
        """اختبار حفظ واسترجاع"""
        store = IdempotencyStore()

        key = "idp_test_123"
        response = {"id": "acc_123", "status": "created"}

        store.set(key, response)
        retrieved = store.get(key)

        assert retrieved is not None
        assert retrieved == response

    def test_idempotency_key_expiration(self):
        """اختبار انتهاء صلاحية المفتاح"""
        from datetime import timedelta

        store = IdempotencyStore()
        store._ttl = timedelta(seconds=0)  # Set TTL to 0 for immediate expiration

        key = "idp_test_expired"
        response = {"test": "data"}

        store.set(key, response)
        time.sleep(0.1)  # Small delay

        retrieved = store.get(key)
        assert retrieved is None

    def test_idempotency_cleanup(self):
        """اختبار تنظيف المفاتيح المنتهية"""
        from datetime import timedelta

        store = IdempotencyStore()
        store._ttl = timedelta(seconds=0)

        store.set("key1", {"data": 1})
        store.set("key2", {"data": 2})

        time.sleep(0.1)
        store.cleanup()

        assert len(store._store) == 0


# =============================================================================
# Rate Limiting Tests
# =============================================================================


class TestRateLimiting:
    """اختبارات تحديد المعدل"""

    def test_rate_limiter_basic(self):
        """اختبار تحديد المعدل الأساسي"""
        config = RateLimitConfig(requests_per_minute=5)
        limiter = RateLimiter(config)

        key = "test_user"

        # Should allow first 5 requests
        for i in range(5):
            allowed, info = limiter.check_limit(key)
            assert allowed is True
            assert info["remaining"] == 4 - i

        # Should deny 6th request
        allowed, info = limiter.check_limit(key)
        assert allowed is False
        assert info["remaining"] == 0

    def test_rate_limiter_reset(self):
        """اختبار إعادة تعيين الحد"""
        config = RateLimitConfig(requests_per_minute=5)
        limiter = RateLimiter(config)

        key = "test_user"

        # Use up the limit
        for _ in range(5):
            limiter.check_limit(key)

        # Manually reset by advancing time
        limiter._buckets[key]["minute"] = int(time.time() / 60) - 1

        # Should allow again
        allowed, info = limiter.check_limit(key)
        assert allowed is True

    def test_rate_limiter_multiple_keys(self):
        """اختبار تحديد المعدل لمفاتيح متعددة"""
        config = RateLimitConfig(requests_per_minute=3)
        limiter = RateLimiter(config)

        # Different keys should have independent limits
