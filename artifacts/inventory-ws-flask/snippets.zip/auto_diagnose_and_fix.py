#!/usr/bin/env python3
"""
🔍 CogniForge Auto-Diagnostic & Self-Healing System
====================================================
نظام تشخيص وإصلاح ذاتي خارق - Superhuman Auto-Diagnostic System

This script performs comprehensive diagnostics and automated fixes.
Better than tech giants because:
- ✅ Automatic problem detection
- ✅ Self-healing capabilities
- ✅ Bilingual support (Arabic + English)
- ✅ Detailed reporting
- ✅ Interactive mode

Usage:
    python3 auto_diagnose_and_fix.py              # Interactive mode
    python3 auto_diagnose_and_fix.py --auto-fix   # Automatic fix mode
    python3 auto_diagnose_and_fix.py --report     # Report only mode
"""

import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path


class Colors:
    """ANSI color codes for terminal output"""

    HEADER = "\033[95m"
    OKBLUE = "\033[94m"
    OKCYAN = "\033[96m"
    OKGREEN = "\033[92m"
    WARNING = "\033[93m"
    FAIL = "\033[91m"
    ENDC = "\033[0m"
    BOLD = "\033[1m"
    UNDERLINE = "\033[4m"


class DiagnosticResult:
    """Represents a diagnostic check result"""

    def __init__(
        self,
        check_name: str,
        passed: bool,
        message: str,
        severity: str = "info",
        fix_available: bool = False,
    ):
        self.check_name = check_name
        self.passed = passed
        self.message = message
        self.severity = severity  # critical, high, medium, low, info
        self.fix_available = fix_available
        self.timestamp = datetime.now()


class CogniForgeAutoDiagnostic:
    """Main diagnostic and self-healing system"""

    def __init__(self, auto_fix: bool = False):
        self.auto_fix = auto_fix
        self.results: list[DiagnosticResult] = []
        self.fixes_applied: list[str] = []
        self.project_root = Path.cwd()

    def print_header(self):
        """Print diagnostic header"""
        print(f"\n{Colors.BOLD}{Colors.OKCYAN}{'=' * 80}{Colors.ENDC}")
        print(
            f"{Colors.BOLD}{Colors.OKCYAN}🔍 CogniForge Auto-Diagnostic & Self-Healing System{Colors.ENDC}"
        )
        print(f"{Colors.BOLD}{Colors.OKCYAN}نظام التشخيص والإصلاح الذاتي الخارق{Colors.ENDC}")
        print(f"{Colors.BOLD}{Colors.OKCYAN}{'=' * 80}{Colors.ENDC}\n")
        print(f"📅 Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"📂 Project Root: {self.project_root}")
        print(f"🔧 Auto-Fix Mode: {'ON' if self.auto_fix else 'OFF'}")
        print()

    def print_section(self, title: str, icon: str = "📋"):
        """Print section header"""
        print(f"\n{Colors.BOLD}{icon} {title}{Colors.ENDC}")
        print(f"{Colors.BOLD}{'-' * 80}{Colors.ENDC}")

    def add_result(self, result: DiagnosticResult):
        """Add a diagnostic result"""
        self.results.append(result)

        # Print result immediately
        status_icon = "✅" if result.passed else "❌"
        status_color = Colors.OKGREEN if result.passed else Colors.FAIL

        print(f"{status_color}{status_icon} {result.check_name}{Colors.ENDC}")
        print(f"   {result.message}")

        if not result.passed and result.fix_available:
            print(f"   {Colors.WARNING}🔧 Fix available{Colors.ENDC}")

    def check_env_file(self) -> DiagnosticResult:
        """Check if .env file exists"""
        env_file = self.project_root / ".env"

        if env_file.exists():
            return DiagnosticResult(
                check_name="ملف .env موجود / .env file exists",
                passed=True,
                message="✓ .env file found",
                severity="info",
            )
        else:
            return DiagnosticResult(
                check_name="ملف .env موجود / .env file exists",
                passed=False,
                message="✗ .env file not found - AI features will not work",
                severity="critical",
                fix_available=True,
            )

    def fix_env_file(self) -> bool:
        """Create .env file from .env.example"""
        try:
            env_example = self.project_root / ".env.example"
            env_file = self.project_root / ".env"

            if not env_example.exists():
                print(f"{Colors.FAIL}   ❌ Cannot create .env: .env.example not found{Colors.ENDC}")
                return False

            shutil.copy(env_example, env_file)
            self.fixes_applied.append("Created .env file from .env.example")
            print(f"{Colors.OKGREEN}   ✅ Created .env file{Colors.ENDC}")
            return True

        except Exception as e:
            print(f"{Colors.FAIL}   ❌ Failed to create .env: {e}{Colors.ENDC}")
            return False

    def check_api_keys(self) -> list[DiagnosticResult]:
        """Check if API keys are configured"""
        results = []

        # Load .env file
        env_file = self.project_root / ".env"
        env_vars = {}

        if env_file.exists():
            with open(env_file) as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith("#") and "=" in line:
                        key, value = line.split("=", 1)
                        env_vars[key.strip()] = value.strip()

        # Check OPENROUTER_API_KEY
        openrouter_key = env_vars.get("OPENROUTER_API_KEY", "")
        openai_key = env_vars.get("OPENAI_API_KEY", "")

        # Check if keys are real (not example values)
        openrouter_valid = openrouter_key and not openrouter_key.startswith("sk-or-v1-xxx")
        openai_valid = openai_key and not openai_key.startswith("sk-xxx")

        if openrouter_valid or openai_valid:
            results.append(
                DiagnosticResult(
                    check_name="مفاتيح API مُكونة / API keys configured",
                    passed=True,
                    message=f"✓ API keys configured (OpenRouter: {openrouter_valid}, OpenAI: {openai_valid})",
                    severity="info",
                )
            )
        else:
            results.append(
                DiagnosticResult(
                    check_name="مفاتيح API مُكونة / API keys configured",
                    passed=False,
                    message="✗ No valid API keys found - Please add OPENROUTER_API_KEY or OPENAI_API_KEY to .env",
                    severity="critical",
                    fix_available=False,  # Requires manual action
                )
            )

        return results

    def check_database_connection(self) -> DiagnosticResult:
        """Check database connection"""
        try:
            # Try to import and connect
            result = subprocess.run(
                [
                    "python3",
                    "-c",
                    "from app import create_app, db; app = create_app(); "
                    'app.app_context().push(); db.engine.connect(); print("OK")',
                ],
                capture_output=True,
                text=True,
                timeout=10,
