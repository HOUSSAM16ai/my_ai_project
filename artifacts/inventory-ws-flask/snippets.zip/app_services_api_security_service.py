# app/services/api_security_service.py
# ======================================================================================
# ==        WORLD-CLASS API SECURITY SERVICE (v1.0 - ZERO-TRUST EDITION)            ==
# ======================================================================================
# PRIME DIRECTIVE:
#   نظام أمان متقدم خارق يطبق Zero-Trust Architecture
#   ✨ المميزات الخارقة:
#   - Zero-Trust security model with request signing
#   - Short-lived JWT tokens with automatic rotation
#   - Request signature verification (HMAC-SHA256)
#   - Rate limiting with adaptive throttling
#   - Automated vulnerability detection
#   - Security audit logging with compliance tracking
#   - Multi-factor authentication support
#   - IP whitelist/blacklist management

import hashlib
import hmac
import secrets
import threading
import time
from collections import deque
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from functools import wraps
from typing import Any

import jwt
from flask import current_app, g, jsonify, request
from flask_login import current_user

# ======================================================================================
# CONFIGURATION & CONSTANTS
# ======================================================================================

# JWT Configuration
JWT_ALGORITHM = "HS256"
JWT_ACCESS_TOKEN_EXPIRES = timedelta(minutes=15)  # Short-lived tokens
JWT_REFRESH_TOKEN_EXPIRES = timedelta(days=7)
JWT_ISSUER = "cogniforge-api"

# Rate Limiting Configuration
RATE_LIMIT_REQUESTS = 100  # requests per window
RATE_LIMIT_WINDOW = 60  # seconds
RATE_LIMIT_BURST = 150  # burst allowance

# Security Headers
SECURITY_HEADERS = {
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "X-XSS-Protection": "1; mode=block",
    "Strict-Transport-Security": "max-age=31536000; includeSubDomains",
    "Content-Security-Policy": "default-src 'self'",
    "Referrer-Policy": "strict-origin-when-cross-origin",
}


# ======================================================================================
# DATA STRUCTURES
# ======================================================================================


@dataclass
class SecurityToken:
    """Security token with metadata"""

    token: str
    token_type: str  # 'access' or 'refresh'
    user_id: int
    expires_at: datetime
    issued_at: datetime
    jti: str  # JWT ID for revocation
    scopes: list[str] = field(default_factory=list)

    @property
    def expires_in(self) -> int:
        """Get token expiration time in seconds"""
        return int((self.expires_at - self.issued_at).total_seconds())


@dataclass
class RequestSignature:
    """Request signature for verification"""

    signature: str
    timestamp: int
    nonce: str
    method: str
    path: str
    body_hash: str | None = None


@dataclass
class SecurityAuditLog:
    """Security audit log entry"""

    log_id: str
    timestamp: datetime
    event_type: str  # 'auth', 'rate_limit', 'signature_verify', 'vulnerability', etc.
    user_id: int | None
    ip_address: str
    endpoint: str
    status: str  # 'success', 'failure', 'blocked'
    details: dict[str, Any]
    severity: str  # 'info', 'warning', 'critical'


@dataclass
class RateLimitState:
    """Rate limit state for a client"""

    client_id: str
    requests: deque
    blocked_until: datetime | None = None
    violation_count: int = 0


# ======================================================================================
# SECURITY SERVICE
# ======================================================================================


class APISecurityService:
    """
    خدمة الأمان الخارقة - World-class security service

    Features:
    - Zero-Trust architecture with request signing
    - Short-lived JWT tokens with automatic rotation
    - Adaptive rate limiting with ML-based throttling
    - Security audit logging for compliance
    - Automated vulnerability detection
    - IP-based access control
    """

    def __init__(self):
        self.revoked_tokens: set = set()
        self.rate_limit_states: dict[str, RateLimitState] = {}
        self.security_audit_logs: deque = deque(maxlen=10000)
        self.ip_blacklist: set = set()
        self.ip_whitelist: set = set()
        self.lock = threading.RLock()  # Use RLock to allow recursive locking

        # ML-based adaptive rate limiting
        self.client_behavior_baseline: dict[str, float] = {}

    # ==================================================================================
    # JWT TOKEN MANAGEMENT (SHORT-LIVED)
    # ==================================================================================

    def generate_access_token(self, user_id: int, scopes: list[str] | None = None) -> SecurityToken:
        """Generate short-lived access token (15 minutes)"""
        jti = secrets.token_urlsafe(16)
        now = datetime.now(UTC)
        expires_at = now + JWT_ACCESS_TOKEN_EXPIRES

        payload = {
            "user_id": user_id,
            "jti": jti,
            "iss": JWT_ISSUER,
            "iat": now,
            "exp": expires_at,
            "type": "access",
            "scopes": scopes or [],
        }

        secret = self._get_jwt_secret()
        token = jwt.encode(payload, secret, algorithm=JWT_ALGORITHM)

        return SecurityToken(
            token=token,
            token_type="access",
            user_id=user_id,
            expires_at=expires_at,
            issued_at=now,
            jti=jti,
            scopes=scopes or [],
        )

    def generate_refresh_token(self, user_id: int) -> SecurityToken:
        """Generate refresh token (7 days)"""
        jti = secrets.token_urlsafe(16)
        now = datetime.now(UTC)
        expires_at = now + JWT_REFRESH_TOKEN_EXPIRES

        payload = {
            "user_id": user_id,
            "jti": jti,
            "iss": JWT_ISSUER,
            "iat": now,
            "exp": expires_at,
            "type": "refresh",
        }

        secret = self._get_jwt_secret()
        token = jwt.encode(payload, secret, algorithm=JWT_ALGORITHM)

        return SecurityToken(
            token=token,
