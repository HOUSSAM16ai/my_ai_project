# app/services/workflow_orchestration_service.py
# ======================================================================================
# ==       SUPERHUMAN WORKFLOW ORCHESTRATION SERVICE (v1.0 - ULTIMATE)            ==
# ======================================================================================
# PRIME DIRECTIVE:
#   نظام Workflow Orchestration خارق يتفوق على Temporal و Cadence
#   ✨ المميزات الخارقة:
#   - Distributed workflow execution
#   - Event-driven orchestration
#   - Automatic retry with exponential backoff
#   - Compensation for failed workflows
#   - Long-running workflow support
#   - State persistence and recovery

from __future__ import annotations

import threading
import time
import uuid
from collections import defaultdict, deque
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum
from typing import Any

from flask import current_app

# ======================================================================================
# ENUMERATIONS
# ======================================================================================


class WorkflowStatus(Enum):
    """Workflow execution status"""

    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    COMPENSATING = "compensating"
    COMPENSATED = "compensated"
    CANCELLED = "cancelled"


class ActivityStatus(Enum):
    """Activity execution status"""

    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    RETRYING = "retrying"


# ======================================================================================
# DATA STRUCTURES
# ======================================================================================


@dataclass
class WorkflowActivity:
    """Workflow activity definition"""

    activity_id: str
    name: str
    handler: str  # Function name to execute
    input_data: dict[str, Any]
    retry_policy: dict[str, Any]
    timeout_seconds: int = 300
    compensation_handler: str | None = None
    status: ActivityStatus = ActivityStatus.PENDING
    result: Any = None
    error: str | None = None
    retry_count: int = 0
    started_at: datetime | None = None
    completed_at: datetime | None = None


@dataclass
class WorkflowDefinition:
    """Workflow definition"""

    workflow_id: str
    name: str
    activities: list[WorkflowActivity]
    event_triggers: list[str]  # Event types that can trigger this workflow
    parallel_execution: bool = False
    status: WorkflowStatus = WorkflowStatus.PENDING
    started_at: datetime | None = None
    completed_at: datetime | None = None
    error: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class WorkflowEvent:
    """Workflow event"""

    event_id: str
    workflow_id: str
    event_type: str
    payload: dict[str, Any]
    timestamp: datetime = field(default_factory=lambda: datetime.now(UTC))


# ======================================================================================
# WORKFLOW ORCHESTRATION SERVICE
# ======================================================================================


class WorkflowOrchestrationService:
    """
    خدمة Workflow Orchestration الخارقة - World-class workflow engine

    Features:
    - Event-driven workflow execution
    - Distributed transaction support
    - Automatic retry and compensation
    - State persistence
    - Long-running workflows
    """

    def __init__(self):
        self.workflows: dict[str, WorkflowDefinition] = {}
        self.workflow_events: deque[WorkflowEvent] = deque(maxlen=10000)
        self.activity_handlers: dict[str, Callable] = {}
        self.event_subscriptions: dict[str, list[str]] = defaultdict(list)
        self.lock = threading.RLock()  # Use RLock to prevent deadlock with nested calls

        current_app.logger.info("Workflow Orchestration Service initialized")

    # ==================================================================================
    # WORKFLOW MANAGEMENT
    # ==================================================================================

    def register_workflow(self, workflow: WorkflowDefinition) -> bool:
        """Register workflow definition"""
        with self.lock:
            self.workflows[workflow.workflow_id] = workflow

            # Subscribe to events
            for event_type in workflow.event_triggers:
                self.event_subscriptions[event_type].append(workflow.workflow_id)

            current_app.logger.info(f"Registered workflow: {workflow.name}")
            return True

    def execute_workflow(self, workflow_id: str) -> WorkflowDefinition | None:
        """Execute workflow"""
        workflow = self.workflows.get(workflow_id)
        if not workflow:
            return None

        workflow.status = WorkflowStatus.RUNNING
        workflow.started_at = datetime.now(UTC)

        try:
            if workflow.parallel_execution:
                self._execute_parallel(workflow)
            else:
                self._execute_sequential(workflow)

            workflow.status = WorkflowStatus.COMPLETED
            workflow.completed_at = datetime.now(UTC)
            current_app.logger.info(f"Workflow completed: {workflow.name}")

        except Exception as e:
            workflow.status = WorkflowStatus.FAILED
            workflow.error = str(e)
            workflow.completed_at = datetime.now(UTC)
            current_app.logger.error(f"Workflow failed: {workflow.name} - {e}")

            # Trigger compensation
            self._compensate_workflow(workflow)

        return workflow

    def _execute_sequential(self, workflow: WorkflowDefinition):
        """Execute activities sequentially"""
        for activity in workflow.activities:
            self._execute_activity(activity)

    def _execute_parallel(self, workflow: WorkflowDefinition):
        """Execute activities in parallel"""
        threads = []
        for activity in workflow.activities:
            thread = threading.Thread(target=self._execute_activity, args=(activity,))
            thread.start()
            threads.append(thread)

        for thread in threads:
            thread.join()

    def _execute_activity(self, activity: WorkflowActivity):
        """Execute single activity with retry"""
        activity.status = ActivityStatus.RUNNING
        activity.started_at = datetime.now(UTC)

        max_retries = activity.retry_policy.get("max_attempts", 3)
