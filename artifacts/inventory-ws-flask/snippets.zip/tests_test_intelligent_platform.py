# tests/test_intelligent_platform.py
"""
Tests for Intelligent Service Platform
"""
from tests._helpers import parse_response_json
from datetime import UTC, datetime

import pytest

from app.services.aiops_self_healing_service import (
    MetricType,
    TelemetryData,
    get_aiops_service,
)
from app.services.data_mesh_service import (
    BoundedContext,
    DataContract,
    DataDomainType,
    DataProduct,
    DataQualityMetrics,
    SchemaCompatibility,
    get_data_mesh_service,
)
from app.services.edge_multicloud_service import (
    PlacementStrategy,
    get_edge_multicloud_service,
)
from app.services.gitops_policy_service import (
    GitOpsApp,
    get_gitops_service,
)
from app.services.sre_error_budget_service import (
    SLO,
    DeploymentStrategy,
    get_sre_service,
)
from app.services.workflow_orchestration_service import (
    WorkflowActivity,
    WorkflowDefinition,
    get_workflow_orchestration_service,
)


class TestDataMeshService:
    """Test Data Mesh service"""

    def test_register_bounded_context(self):
        """Test registering bounded context"""
        data_mesh = get_data_mesh_service()

        context = BoundedContext(
            context_id="test-ctx-1",
            domain=DataDomainType.USER_MANAGEMENT,
            name="Test Context",
            description="Test bounded context",
            data_products=[],
            upstream_contexts=[],
            downstream_contexts=[],
            governance_policies={},
        )

        success = data_mesh.register_bounded_context(context)
        assert success

        retrieved = data_mesh.get_bounded_context("test-ctx-1")
        assert retrieved is not None
        assert retrieved.name == "Test Context"

    def test_create_data_contract(self):
        """Test creating data contract"""
        data_mesh = get_data_mesh_service()

        contract = DataContract(
            contract_id="test-contract-1",
            domain=DataDomainType.USER_MANAGEMENT,
            name="Test Contract",
            description="Test data contract",
            schema_version="1.0.0",
            schema_definition={
                "type": "object",
                "required": ["id"],
                "properties": {"id": {"type": "string"}},
            },
            compatibility_mode=SchemaCompatibility.BACKWARD,
            owners=["test-team"],
            consumers=[],
            sla_guarantees={},
        )

        success = data_mesh.create_data_contract(contract)
        assert success

    def test_record_quality_metrics(self):
        """Test recording quality metrics"""
        data_mesh = get_data_mesh_service()

        # First create a product
        product = DataProduct(
            product_id="test-product-1",
            name="Test Product",
            domain=DataDomainType.USER_MANAGEMENT,
            description="Test product",
            owner_team="test-team",
            contracts=[],
            quality_metrics={},
            access_patterns=[],
            lineage={},
        )
        data_mesh.register_data_product(product)

        metrics = DataQualityMetrics(
            product_id="test-product-1",
            timestamp=datetime.now(UTC),
            completeness=0.98,
            accuracy=0.99,
            consistency=0.97,
            timeliness=0.95,
            freshness_seconds=45,
            volume=1000,
            error_rate=0.01,
        )

        data_mesh.record_quality_metrics(metrics)

        summary = data_mesh.get_quality_summary("test-product-1")
        assert summary is not None
        assert summary["avg_completeness"] >= 0.9


class TestAIOpsService:
    """Test AIOps service"""

    def test_collect_telemetry(self):
        """Test collecting telemetry"""
        aiops = get_aiops_service()

        telemetry = TelemetryData(
            metric_id="test-metric-1",
            service_name="test-service",
            metric_type=MetricType.LATENCY,
            value=100.0,
            timestamp=datetime.now(UTC),
            labels={},
            unit="ms",
        )

        aiops.collect_telemetry(telemetry)

        # Collect more to build baseline
        for i in range(20):
            t = TelemetryData(
                metric_id=f"test-metric-{i}",
                service_name="test-service",
                metric_type=MetricType.LATENCY,
                value=95.0 + i,
                timestamp=datetime.now(UTC),
            )
            aiops.collect_telemetry(t)

    def test_get_service_health(self):
        """Test getting service health"""
        aiops = get_aiops_service()

        health = aiops.get_service_health("test-service")
        assert health is not None
        assert "service_name" in health
        assert health["service_name"] == "test-service"


class TestGitOpsService:
    """Test GitOps service"""

    def test_register_application(self):
        """Test registering GitOps application"""
        gitops = get_gitops_service()

        app = GitOpsApp(
            app_id="test-app-1",
            name="Test App",
            namespace="default",
            git_repo="https://github.com/test/repo",
            git_path="manifests/",
            git_branch="main",
            sync_policy={"auto_sync": False},
            destination={"server": "localhost", "namespace": "default"},
        )

        success = gitops.register_application(app)
        assert success

    def test_policy_evaluation(self):
        """Test policy evaluation"""
        gitops = get_gitops_service()

        resource = {
            "kind": "Deployment",
            "metadata": {"name": "test-deployment"},
            "spec": {
                "template": {
                    "spec": {
