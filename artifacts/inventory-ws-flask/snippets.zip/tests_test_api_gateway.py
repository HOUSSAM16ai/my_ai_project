# tests/test_api_gateway.py
# ======================================================================================
# ==        API GATEWAY TESTS (v1.0 - COMPREHENSIVE EDITION)                        ==
# ======================================================================================
"""
اختبارات شاملة لبوابة API - Comprehensive API Gateway tests

Tests cover:
- Gateway service initialization
- Protocol adapters (REST/GraphQL/gRPC)
- Intelligent routing
- Caching layer
- Policy enforcement
- Chaos engineering
- Circuit breakers
- A/B testing
- Canary deployments
- Feature flags
"""

import pytest

from app.services.api_gateway_chaos import (
    ChaosEngineeringService,
    ChaosExperiment,
    CircuitBreakerConfig,
    CircuitBreakerService,
    CircuitState,
    FaultType,
)
from app.services.api_gateway_deployment import (
    ABTestExperiment,
    ABTestingService,
    CanaryDeployment,
    CanaryDeploymentService,
    FeatureFlag,
    FeatureFlagService,
    FeatureFlagStatus,
)
from app.services.api_gateway_service import (
    GraphQLAdapter,
    IntelligentCache,
    IntelligentRouter,
    PolicyEngine,
    PolicyRule,
    RESTAdapter,
    RoutingStrategy,
)

# ======================================================================================
# INTELLIGENT ROUTER TESTS
# ======================================================================================


class TestIntelligentRouter:
    """Test intelligent routing engine"""

    def test_router_initialization(self):
        """Test router initializes correctly"""
        router = IntelligentRouter()
        assert router is not None
        assert len(router.provider_adapters) > 0

    def test_cost_optimized_routing(self):
        """Test cost-optimized routing strategy"""
        router = IntelligentRouter()

        decision = router.route_request(
            model_type="gpt-3.5-turbo",
            estimated_tokens=100,
            strategy=RoutingStrategy.COST_OPTIMIZED,
        )

        assert decision is not None
        assert decision.service_id in router.provider_adapters
        assert decision.estimated_cost > 0
        assert decision.confidence_score > 0

    def test_latency_based_routing(self):
        """Test latency-based routing strategy"""
        router = IntelligentRouter()

        decision = router.route_request(
            model_type="gpt-4", estimated_tokens=500, strategy=RoutingStrategy.LATENCY_BASED
        )

        assert decision is not None
        assert decision.estimated_latency_ms > 0

    def test_intelligent_routing_with_constraints(self):
        """Test intelligent routing with constraints"""
        router = IntelligentRouter()

        decision = router.route_request(
            model_type="gpt-4",
            estimated_tokens=1000,
            strategy=RoutingStrategy.INTELLIGENT,
            constraints={"max_cost": 0.05, "max_latency": 2000},
        )

        assert decision is not None
        assert decision.estimated_cost <= 0.05
        assert decision.estimated_latency_ms <= 2000

    def test_provider_stats_update(self):
        """Test provider statistics tracking"""
        router = IntelligentRouter()

        # Update stats
        router.update_provider_stats("openai", success=True, latency_ms=150.0)
        router.update_provider_stats("openai", success=True, latency_ms=200.0)
        router.update_provider_stats("openai", success=False, latency_ms=100.0)

        stats = router.provider_stats["openai"]
        assert stats.total_requests == 3
        assert stats.total_errors == 1
        assert stats.avg_latency_ms > 0


# ======================================================================================
# CACHING TESTS
# ======================================================================================


class TestIntelligentCache:
    """Test intelligent caching layer"""

    def test_cache_initialization(self):
        """Test cache initializes correctly"""
        cache = IntelligentCache(max_size_mb=10)
        assert cache.max_size_mb == 10
        assert cache.hit_count == 0
        assert cache.miss_count == 0

    def test_cache_put_and_get(self):
        """Test cache put and get operations"""
        cache = IntelligentCache()

        request_data = {"endpoint": "/api/test", "method": "GET"}
        response_data = {"status": "success", "data": "test"}

        # Put into cache
        cache.put(request_data, response_data, ttl_seconds=300)

        # Get from cache
        result = cache.get(request_data)
        assert result is not None
        assert result["status"] == "success"
        assert cache.hit_count == 1

    def test_cache_miss(self):
        """Test cache miss scenario"""
        cache = IntelligentCache()

        result = cache.get({"endpoint": "/api/nonexistent"})
        assert result is None
        assert cache.miss_count == 1

    def test_cache_expiration(self):
        """Test cache entry expiration"""
        cache = IntelligentCache()

        request_data = {"endpoint": "/api/test"}
        response_data = {"data": "test"}

        # Put with short TTL
        cache.put(request_data, response_data, ttl_seconds=0)

        # Should be expired
        import time

        time.sleep(0.1)
        result = cache.get(request_data)
        assert result is None

    def test_cache_stats(self):
        """Test cache statistics"""
        cache = IntelligentCache()

        # Add some entries
        for i in range(5):
            cache.put({"endpoint": f"/api/test{i}"}, {"data": i}, ttl_seconds=300)

        stats = cache.get_stats()
        assert stats["entry_count"] == 5
        assert stats["hit_rate"] == 0.0  # No hits yet

        # Now get one
        cache.get({"endpoint": "/api/test0"})
        stats = cache.get_stats()
        assert stats["hit_count"] == 1


# ======================================================================================
# POLICY ENGINE TESTS
# ======================================================================================


class TestPolicyEngine:
    """Test policy enforcement engine"""
