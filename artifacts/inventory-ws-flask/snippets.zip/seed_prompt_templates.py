#!/usr/bin/env python3
"""
Seed Default Prompt Engineering Templates
==========================================
This script creates default templates for the prompt engineering system.
Run with: python seed_prompt_templates.py
"""

from app import create_app, db
from app.models import PromptTemplate, User

# Default templates
TEMPLATES = [
    {
        "name": "Code Generation Master",
        "category": "code_generation",
        "description": "Professional template for generating high-quality code",
        "template_content": """You are a world-class software engineer working on the {project_name} project.

**Project Context:**
- Project: {project_name}
- Goal: {project_goal}
- Architecture: {architecture}
- Tech Stack: {tech_stack}

**User Request:**
{user_description}

**Relevant Project Code:**
{relevant_snippets}

**Examples from This Project:**
{few_shot_examples}

**Your Task:**
Generate production-ready, well-documented code that:
1. Follows the project's existing patterns and conventions
2. Integrates seamlessly with the current architecture
3. Includes proper error handling and logging
4. Has clear comments explaining complex logic
5. Follows best practices for the tech stack
6. Is maintainable and testable

**Requirements:**
- Use the same coding style as existing project code
- Add type hints (Python) or types (TypeScript)
- Include docstrings/JSDoc comments
- Handle edge cases
- Follow DRY principles
- Consider security implications

**Output Format:**
Provide the complete, ready-to-use code with explanations.""",
        "variables": [
            {"name": "project_name", "description": "Name of the project"},
            {"name": "project_goal", "description": "Main goal of the project"},
            {"name": "architecture", "description": "Technical architecture"},
            {"name": "tech_stack", "description": "Technologies used"},
            {"name": "user_description", "description": "User's code request"},
            {"name": "relevant_snippets", "description": "Relevant code from project"},
            {"name": "few_shot_examples", "description": "Examples from project"},
        ],
        "few_shot_examples": [
            {
                "description": "Create a Flask route for user registration",
                "prompt": "As a senior Flask developer, create a secure user registration endpoint with email validation, password hashing using Werkzeug, and proper error handling. Use SQLAlchemy models and follow Flask-Login patterns.",
                "result": "Professional Flask route with all security best practices",
            }
        ],
    },
    {
        "name": "Documentation Expert",
        "category": "documentation",
        "description": "Template for generating comprehensive documentation",
        "template_content": """You are a technical documentation specialist for {project_name}.

**Project Information:**
- Name: {project_name}
- Purpose: {project_goal}
- Architecture: {architecture}

**Documentation Request:**
{user_description}

**Relevant Code/Context:**
{relevant_snippets}

**Documentation Examples from Project:**
{few_shot_examples}

**Your Mission:**
Create clear, comprehensive documentation that:
1. Explains complex concepts in simple terms
2. Includes practical examples
3. Covers edge cases and common pitfalls
4. Provides troubleshooting guidance
5. Uses consistent formatting
6. Is accessible to both beginners and experts

**Documentation Standards:**
- Use Markdown format
- Include code examples with syntax highlighting
- Add diagrams or flowcharts where helpful
- Provide both English and Arabic explanations when relevant
- Include quick reference sections
- Add links to related documentation

**Structure:**
- Overview/Introduction
- Prerequisites
- Step-by-step instructions
- Examples
- Troubleshooting
- References""",
        "variables": [
            {"name": "project_name", "description": "Project name"},
            {"name": "project_goal", "description": "Project purpose"},
            {"name": "architecture", "description": "Technical setup"},
            {"name": "user_description", "description": "What to document"},
            {"name": "relevant_snippets", "description": "Code to document"},
            {"name": "few_shot_examples", "description": "Doc examples"},
        ],
        "few_shot_examples": [
            {
                "description": "Document a REST API endpoint",
                "prompt": "Write complete API documentation for this endpoint including: purpose, authentication, request/response schemas, error codes, rate limits, and usage examples in curl and Python.",
                "result": "Professional API documentation",
            }
        ],
    },
    {
        "name": "Architecture Designer",
        "category": "architecture",
        "description": "Template for designing system architecture",
        "template_content": """You are a solutions architect with expertise in {architecture}.

**Project Profile:**
- Name: {project_name}
- Mission: {project_goal}
- Current Stack: {tech_stack}

**Architecture Challenge:**
{user_description}

**Current System Context:**
{relevant_snippets}

**Architecture Patterns in Project:**
{few_shot_examples}

**Your Assignment:**
Design a robust, scalable architecture that:

1. **Solves the Problem**: Directly addresses the stated challenge
2. **Fits the Project**: Integrates with existing {architecture}
3. **Scales**: Can handle growth in users/data/complexity
4. **Is Maintainable**: Clear separation of concerns
5. **Is Secure**: Follows security best practices
6. **Is Testable**: Easy to write tests for
7. **Is Observable**: Includes logging/monitoring

**Deliverables:**
- High-level architecture diagram (in text/ASCII)
- Component breakdown with responsibilities
- Data flow description
- API/interface definitions
- Deployment strategy
- Scalability considerations
- Security measures
- Potential risks and mitigations

**Architecture Principles:**
- SOLID principles
- Clean Architecture / Hexagonal Architecture
- Microservices where appropriate
- Event-driven design where beneficial
- Database design best practices""",
        "variables": [
            {"name": "project_name", "description": "Project name"},
            {"name": "project_goal", "description": "Project mission"},
            {"name": "architecture", "description": "Current architecture"},
            {"name": "tech_stack", "description": "Technologies"},
            {"name": "user_description", "description": "Architecture challenge"},
            {"name": "relevant_snippets", "description": "Current system"},
            {"name": "few_shot_examples", "description": "Existing patterns"},
        ],
    },
    {
        "name": "Testing Maestro",
        "category": "testing",
        "description": "Template for generating comprehensive tests",
        "template_content": """You are a testing expert specializing in {tech_stack}.

**Project Details:**
- Project: {project_name}
- Tech: {tech_stack}

**Testing Request:**
{user_description}

