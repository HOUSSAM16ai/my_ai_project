#!/usr/bin/env python3
"""
🚀 SUPABASE CONNECTION SETUP & VERIFICATION SCRIPT
===================================================
This script sets up and verifies the connection to the new Supabase project.

Project Details:
- Host: db.aocnuqhxrhxgbfcgbxfy.supabase.co
- Database: postgres
- Port: 5432

Author: Houssam Benmerah
Version: 1.0.0
"""

import os
import sys
from pathlib import Path

from dotenv import load_dotenv

# Load environment variables
load_dotenv()

import traceback  # noqa: E402
from datetime import datetime  # noqa: E402

from sqlalchemy import create_engine, inspect, text  # noqa: E402
from sqlalchemy.orm import sessionmaker  # noqa: E402

# ANSI Colors for beautiful output
G = "\033[92m"  # Green
Y = "\033[93m"  # Yellow
R = "\033[91m"  # Red
B = "\033[94m"  # Blue
M = "\033[95m"  # Magenta
C = "\033[96m"  # Cyan
W = "\033[97m"  # White
E = "\033[0m"  # End


def print_header(text):
    """Print a beautiful header"""
    print(f"\n{B}{'=' * 70}{E}")
    print(f"{C}{text}{E}")
    print(f"{B}{'=' * 70}{E}\n")


def print_success(text):
    """Print success message"""
    print(f"{G}✅ {text}{E}")


def print_error(text):
    """Print error message"""
    print(f"{R}❌ {text}{E}")


def print_warning(text):
    """Print warning message"""
    print(f"{Y}⚠️  {text}{E}")


def print_info(text):
    """Print info message"""
    print(f"{B}ℹ️  {text}{E}")


def verify_environment():
    """Verify environment variables"""
    print_header("📋 STEP 1: VERIFY ENVIRONMENT VARIABLES")

    db_url = os.getenv("DATABASE_URL")

    if not db_url:
        print_error("DATABASE_URL not found in environment!")
        print_info("Please ensure .env file exists and contains DATABASE_URL")
        return False

    # Verify the URL points to the correct Supabase project
    if "aocnuqhxrhxgbfcgbxfy.supabase.co" in db_url:
        print_success("DATABASE_URL points to correct Supabase project: aocnuqhxrhxgbfcgbxfy")
    else:
        print_warning("DATABASE_URL doesn't point to the expected Supabase project")
        print_info(f"Current URL: {db_url[:50]}...")

    # Verify password encoding
    if "199720242025%40HOUSSAMbenmerah" in db_url:
        print_success("Password is correctly URL-encoded (@ -> %40)")
    else:
        print_warning("Password encoding might be incorrect")

    print_success("Environment variables verified")
    return True


def test_connection():
    """Test database connection"""
    print_header("🔌 STEP 2: TEST DATABASE CONNECTION")

    db_url = os.getenv("DATABASE_URL")

    try:
        print_info("Creating database engine...")
        engine = create_engine(db_url, pool_pre_ping=True)

        print_info("Attempting to connect...")
        with engine.connect() as conn:
            # Get PostgreSQL version
            result = conn.execute(text("SELECT version();"))
            version = result.fetchone()[0]
            print_success("Connection established successfully!")
            print_info(f"PostgreSQL version: {version.split(',')[0]}")

            # Get current database name
            result = conn.execute(text("SELECT current_database();"))
            db_name = result.fetchone()[0]
            print_info(f"Connected to database: {db_name}")

            # Get current user
            result = conn.execute(text("SELECT current_user;"))
            user = result.fetchone()[0]
            print_info(f"Connected as user: {user}")

        return engine

    except Exception as e:
        print_error(f"Connection failed: {str(e)}")
        print_info("Traceback:")
        traceback.print_exc()
        return None


def check_tables(engine):
    """Check existing tables in database"""
    print_header("📊 STEP 3: CHECK EXISTING TABLES")

    try:
        inspector = inspect(engine)
        tables = inspector.get_table_names()

        if tables:
            print_success(f"Found {len(tables)} tables in database:")
            for i, table in enumerate(sorted(tables), 1):
                print(f"   {i}. {table}")
        else:
            print_warning("No tables found in database")
            print_info("This is expected for a fresh Supabase project")
            print_info("Tables will be created when migrations are applied")

        return tables

    except Exception as e:
        print_error(f"Failed to check tables: {str(e)}")
        return []


def check_migrations():
    """Check migration status"""
    print_header("🔄 STEP 4: CHECK MIGRATION STATUS")

    migrations_dir = Path(__file__).parent / "migrations" / "versions"

    if not migrations_dir.exists():
        print_error("Migrations directory not found!")
        return False

    migration_files = sorted(migrations_dir.glob("*.py"))
    migration_files = [f for f in migration_files if f.name != "__pycache__"]

    print_success(f"Found {len(migration_files)} migration files:")
    for i, migration in enumerate(migration_files, 1):
        # Extract migration name
        name = migration.stem
        print(f"   {i}. {name}")

    print_info("\nTo apply these migrations, run:")
    print(f"   {B}flask db upgrade{E}")

    return True


def apply_migrations(engine):
    """Apply database migrations"""
    print_header("🚀 STEP 5: APPLY DATABASE MIGRATIONS")

    try:
        print_info("Importing Flask app to apply migrations...")

        from app import create_app
        from app import db as flask_db

        app = create_app("development")

        with app.app_context():
            print_info("Running flask db upgrade...")

            # Check current database revision
            from alembic import command
            from alembic.config import Config as AlembicConfig
