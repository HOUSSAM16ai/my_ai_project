# 🎯 API Gateway - Quick Start Guide

> **دليل البدء السريع لبوابة API**
>
> **Quick start guide for the superhuman API Gateway**

---

## 📋 Installation

The API Gateway is already integrated into the project. No additional installation required!

```bash
# Verify gateway services are available
python3 -m pytest tests/test_api_gateway.py -v
```

---

## 🚀 Basic Usage

### 1. Using the Intelligent Router

Route requests to the optimal AI provider based on cost, latency, or balanced criteria:

```python
from app.services.api_gateway_service import get_gateway_service, RoutingStrategy
from flask import current_app

# Get gateway instance
gateway = get_gateway_service()

# Route request intelligently
decision = gateway.intelligent_router.route_request(
    model_type="gpt-4",
    estimated_tokens=500,
    strategy=RoutingStrategy.INTELLIGENT,
    constraints={
        'max_cost': 0.05,
        'max_latency': 2000
    }
)

print(f"Selected provider: {decision.service_id}")
print(f"Estimated cost: ${decision.estimated_cost:.4f}")
print(f"Estimated latency: {decision.estimated_latency_ms}ms")
print(f"Confidence: {decision.confidence_score:.2f}")
```

**Output:**
```
Selected provider: openai
Estimated cost: $0.0010
Estimated latency: 750ms
Confidence: 0.85
```

---

### 2. Using Intelligent Caching

Cache expensive AI operations automatically:

```python
from app.services.api_gateway_service import get_gateway_service

gateway = get_gateway_service()

# Request data (cache key)
request_data = {
    'query': 'Explain quantum computing',
    'model': 'gpt-4',
    'temperature': 0.7
}

# Check cache first
cached_response = gateway.cache.get(request_data)
if cached_response:
    print("✅ Cache hit! Using cached response")
    result = cached_response
else:
    print("❌ Cache miss, calling API...")
    # Make expensive API call
    result = {'response': 'Quantum computing explanation...'}
    
    # Cache for 5 minutes
    gateway.cache.put(request_data, result, ttl_seconds=300)

# Get cache statistics
stats = gateway.cache.get_stats()
print(f"Cache hit rate: {stats['hit_rate']:.1%}")
print(f"Cached entries: {stats['entry_count']}")
```

---

### 3. Policy Enforcement

Enforce access control and compliance policies:

```python
from app.services.api_gateway_service import PolicyEngine, PolicyRule

engine = PolicyEngine()

# Add authentication policy
auth_policy = PolicyRule(
    rule_id="require_auth",
    name="Require Authentication",
    condition="auth_required and not authenticated",
    action="deny",
    priority=100,
    enabled=True
)
engine.add_policy(auth_policy)

# Evaluate request
request_context = {
    'authenticated': False,
    'endpoint': '/api/protected',
    'user_id': None
}

allowed, reason = engine.evaluate(request_context)
if not allowed:
    print(f"❌ Request denied: {reason}")
else:
    print("✅ Request allowed")
```

---

### 4. Chaos Engineering

Test system resilience with controlled fault injection:

```python
from app.services.api_gateway_chaos import (
    get_chaos_service,
    ChaosExperiment,
    FaultType
)

chaos = get_chaos_service()

# Create latency injection experiment
experiment = ChaosExperiment(
    experiment_id="latency_test_1",
    name="API Latency Test",
    description="Test system resilience to increased latency",
    fault_type=FaultType.LATENCY,
    target_service="openai",
    fault_rate=0.2,  # Inject fault in 20% of requests
    duration_seconds=300  # Run for 5 minutes
)

# Start experiment
if chaos.start_experiment(experiment):
    print("✅ Chaos experiment started")
    print(f"   Injecting {experiment.fault_type.value} faults")
    print(f"   Fault rate: {experiment.fault_rate * 100}%")
    print(f"   Duration: {experiment.duration_seconds}s")

# Later: stop experiment
chaos.stop_experiment("latency_test_1")
print("✅ Chaos experiment stopped")
```

---

### 5. Circuit Breaker Pattern

Protect against cascading failures:

```python
from app.services.api_gateway_chaos import (
    get_circuit_breaker,
    CircuitBreakerConfig
)

# Configure circuit breaker
config = CircuitBreakerConfig(
    failure_threshold=5,  # Open after 5 failures
    timeout_seconds=60,   # Stay open for 60 seconds
    half_open_requests=3  # Test with 3 requests before closing
)

cb = get_circuit_breaker()

# Call external service through circuit breaker
def call_external_api():
    # Your API call here
    import requests
    response = requests.get('https://api.example.com/data')
    return response.json()

success, result, error = cb.call("external_api", call_external_api)

if success:
    print(f"✅ API call successful: {result}")
