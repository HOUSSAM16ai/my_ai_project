# app/services/llm_client_service.py - The Central Communications Ministry
# =================================================================================================
#  LLM CLIENT SERVICE – HYPER PRO EDITION
#  Version: 4.7.0  •  Codename: "RESILIENT-COMMS-ULTRA / RETRY+STREAM / COST / CIRCUIT / HOOKS"
# =================================================================================================
#  PURPOSE
#    Single Authoritative Gateway for all LLM invocations across the Overmind stack:
#      - Unified construction & reuse (lazy singleton; optional cache disable).
#      - Automatic multi-provider credential detection (OpenRouter → OpenAI).
#      - Modern + legacy OpenAI SDK compatibility + lightweight HTTP fallback.
#      - Resilient high-level interface invoke_chat() + optional streaming.
#      - Structured response envelope (content / usage / latency / cost / meta).
#      - Retries with exponential backoff + jitter + error taxonomy.
#      - Circuit breaker for repeated transient failures.
#      - Cumulative usage & (optional) cost estimation (per model rate table).
#      - Hooks (pre / post) for dynamic policy injection, tracing, sanitization.
#      - Output sanitization (sensitive marker redaction).
#      - Force-model override, configurable timeouts, mock fallback modes.
#      - Health diagnostics (llm_health) enriched with latency & breaker state.
#
#  COMPATIBILITY
#    - Backward compatible with legacy direct usage: client.chat.completions.create(...)
#    - New advanced consumers should prefer invoke_chat() or invoke_chat_stream().
#
#  NEW vs 4.6.0
#    + Dedicated invoke_chat_stream() helper.
#    + Circuit Breaker (configurable window / threshold / cooldown).
#    + Budget Guard (session cost ceiling).
#    + Smart Retry Policy (skip retry for auth_error / parse unless configured).
#    + Selective Retry Error Classes.
#    + Cost Budget Hard-Fail vs Soft Warn.
#    + Model alias normalization (optional mapping).
#    + Expanded Sanitization patterns + optional regex redaction.
#    + Fine-grained logging levels for attempts & breaker events.
#    + Minimal internal stats snapshot (for external orchestrators).
#
#  ENV VARS (Key Subset)
#    OPENROUTER_API_KEY                Primary key (priority #1)
#    OPENAI_API_KEY                    Secondary key
#    LLM_BASE_URL                      Override base URL
#    LLM_TIMEOUT_SECONDS=180            # Default timeout (auto-adjusts in extreme/ultimate modes)
#    LLM_FORCE_MOCK=0|1
#    LLM_MOCK_MODE=0|1                 (alias)
#    LLM_DISABLE_CACHE=0|1
#    LLM_HTTP_FALLBACK=0|1
#
#    LLM_MAX_RETRIES=2                  # Default retries (auto-increases in extreme/ultimate modes)
#    LLM_RETRY_BACKOFF_BASE=1.3
#    LLM_RETRY_JITTER=1
#    LLM_RETRY_ON_AUTH=0              (auth_error normally not retried)
#    LLM_RETRY_ON_PARSE=0
#    LLM_EXTREME_COMPLEXITY_MODE=0    # When 1: 8 retries, 600s timeout, backoff 1.5
#    LLM_ULTIMATE_COMPLEXITY_MODE=0   # When 1: 20 retries, 1800s timeout, backoff 1.8 (SUPERHUMAN MODE)
#
#    LLM_ENABLE_STREAM=0
#    LLM_FORCE_MODEL=""               Force override model name
#    LLM_SANITIZE_OUTPUT=0
#    LLM_SANITIZE_REGEXES_JSON='["OPENAI_API_KEY=[A-Za-z0-9_-]+"]'
#
#    MODEL_COST_TABLE_JSON='{"openai/gpt-4o":{"prompt":0.000002,"completion":0.000006}}'
#    MODEL_ALIAS_MAP_JSON='{"gpt-4o":"openai/gpt-4o"}'
#
#    LLM_COST_BUDGET_SESSION=0        (0 => disabled; else numeric USD upper limit)
#    LLM_COST_BUDGET_HARD_FAIL=0      (if 1 and budget exceeded → raise error)
#
#    # Circuit Breaker
#    LLM_BREAKER_WINDOW=60            (seconds)
#    LLM_BREAKER_ERROR_THRESHOLD=6
#    LLM_BREAKER_COOLDOWN=30
#
#    # Logging
#    LLM_LOG_LEVEL=INFO
#    LLM_LOG_ATTEMPTS=1
#
#  PUBLIC API
#    get_llm_client()
#    reset_llm_client()
#    is_mock_client(client=None)
#    llm_health()
#    invoke_chat(...)
#    invoke_chat_stream(... generator ...)
#    register_llm_pre_hook(fn)
#    register_llm_post_hook(fn)
#
#  RESPONSE ENVELOPE (invoke_chat)
#    {
#      "content": str,
#      "tool_calls": list|None,
#      "usage": {prompt_tokens, completion_tokens, total_tokens},
#      "model": str,
#      "provider": str|None,
#      "latency_ms": float,
#      "cost": float|None,
#      "raw": <original completion object>,
#      "meta": {
#          "attempts": int,
#          "forced_model": bool,
#          "http_fallback": bool|None,
#          "build_seq": int,
#          "stream": bool,
#          "start_ts": float,
#          "end_ts": float,
#          "circuit_breaker_open": bool,
#          "retry_schedule": [<floats>]
#      }
#    }
#
#  LICENSE / NOTE
#    Internal proprietary orchestration layer snippet – adapt carefully.
# =================================================================================================

from __future__ import annotations

import json
import os
import random
import re
import threading
import time
import uuid
from collections.abc import Callable, Generator
from typing import Any

# --------------------------------------------------------------------------------------
# Optional dependencies
# --------------------------------------------------------------------------------------
try:
    import openai  # Modern SDK (v1.x with class OpenAI) OR legacy structure
except Exception:  # pragma: no cover
    openai = None
try:
    import requests  # For HTTP fallback
except Exception:  # pragma: no cover
    requests = None
try:
    from flask import current_app, has_app_context
except Exception:  # pragma: no cover
    current_app = None

    def has_app_context() -> bool:
        return False


import contextlib
import logging

# --------------------------------------------------------------------------------------
# Logging
# --------------------------------------------------------------------------------------
_LOG = logging.getLogger("llm.client.service")
_level = os.getenv("LLM_LOG_LEVEL", "INFO").upper()
try:
    _LOG.setLevel(getattr(logging, _level, logging.INFO))
except Exception:
    _LOG.setLevel(logging.INFO)
if not _LOG.handlers:
    _h = logging.StreamHandler()
    _h.setFormatter(logging.Formatter("[%(asctime)s][%(levelname)s][llm.client] %(message)s"))
    _LOG.addHandler(_h)

_LOG_ATTEMPTS = os.getenv("LLM_LOG_ATTEMPTS", "1") == "1"

# --------------------------------------------------------------------------------------
# GLOBAL SINGLETON STATE
# --------------------------------------------------------------------------------------
_CLIENT_SINGLETON: Any | None = None
_CLIENT_LOCK = threading.Lock()
_CLIENT_META: dict[str, Any] = {}
_CLIENT_BUILD_SEQ = 0

# ======================================================================================
# MOCK CLIENT
# ======================================================================================


class MockLLMClient:
    """
    Mock client with minimal compatibility.
    """

    def __init__(self, reason: str, model_alias: str = "mock/virtual-model"):
        self._reason = reason
        self._created_at = time.time()
        self._calls = 0
        self._model = model_alias
        self._id = str(uuid.uuid4())

    class _ChatWrapper:
        def __init__(self, parent: MockLLMClient):
            self._parent = parent

        class _CompletionsWrapper:
            def __init__(self, parent: MockLLMClient):
                self._parent = parent

            def create(
                self,
                model: str,
                messages: list[dict[str, str]],
                tools=None,
