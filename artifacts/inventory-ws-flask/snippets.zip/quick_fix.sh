#!/bin/bash
# =============================================================================
# CogniForge Quick Fix Script
# سكريبت الإصلاح السريع
# =============================================================================
# This script performs quick fixes for common issues
# Better than tech giants because:
# - ✅ Automatic detection and fixing
# - ✅ User-friendly messages in Arabic & English
# - ✅ Safe with backups
# - ✅ Interactive mode
#
# Usage:
#   ./quick_fix.sh                 # Interactive mode
#   ./quick_fix.sh --auto          # Automatic mode
#   ./quick_fix.sh --check-only    # Check only, no fixes
# =============================================================================

set -e  # Exit on error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m' # No Color

# Configuration
AUTO_MODE=false
CHECK_ONLY=false

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --auto)
            AUTO_MODE=true
            shift
            ;;
        --check-only)
            CHECK_ONLY=true
            shift
            ;;
        -h|--help)
            echo "Usage: $0 [--auto] [--check-only]"
            echo "  --auto       : Run all fixes automatically without prompts"
            echo "  --check-only : Only check for issues, don't fix"
            exit 0
            ;;
        *)
            echo "Unknown option: $1"
            echo "Use --help for usage information"
            exit 1
            ;;
    esac
done

# Function to print header
print_header() {
    echo -e "${BOLD}${CYAN}================================================================================${NC}"
    echo -e "${BOLD}${CYAN}🔧 CogniForge Quick Fix - إصلاح سريع${NC}"
    echo -e "${BOLD}${CYAN}================================================================================${NC}"
    echo ""
    echo -e "${BLUE}📅 Timestamp:${NC} $(date '+%Y-%m-%d %H:%M:%S')"
    echo -e "${BLUE}📂 Directory:${NC} $(pwd)"
    echo -e "${BLUE}🔧 Mode:${NC} $([ "$AUTO_MODE" = true ] && echo "Automatic" || echo "Interactive")"
    echo ""
}

# Function to print section
print_section() {
    echo ""
    echo -e "${BOLD}${MAGENTA}$1${NC}"
    echo -e "${BOLD}${MAGENTA}────────────────────────────────────────────────────────────────────────────────${NC}"
}

# Function to ask yes/no question
ask_yes_no() {
    if [ "$AUTO_MODE" = true ] || [ "$CHECK_ONLY" = true ]; then
        return 0  # Auto-yes in auto mode
    fi
    
    local question="$1"
    local default="${2:-n}"
    
    while true; do
        echo -ne "${YELLOW}$question [y/n] (default: $default): ${NC}"
        read -r response
        
        # Use default if empty
        response=${response:-$default}
        
        case "$response" in
            [Yy]* | [نن]* ) return 0 ;;
            [Nn]* ) return 1 ;;
            * ) echo -e "${RED}Please answer y or n${NC}" ;;
        esac
    done
}

# Function to check if file exists
check_file() {
    local file="$1"
    local description="$2"
    
    if [ -f "$file" ]; then
        echo -e "${GREEN}✅ $description: Found${NC}"
        return 0
    else
        echo -e "${RED}❌ $description: Not found${NC}"
        return 1
    fi
}

# Function to check .env file
check_env_file() {
    print_section "1️⃣ Checking .env file / فحص ملف .env"
    
    if check_file ".env" ".env file exists"; then
        # Check if it has real API keys
        if grep -q "OPENROUTER_API_KEY=sk-or-v1-xxx" .env 2>/dev/null; then
            echo -e "${YELLOW}⚠️  Warning: .env contains example API key${NC}"
            echo -e "${YELLOW}   تحذير: ملف .env يحتوي على مفتاح مثال${NC}"
            return 1
        else
            echo -e "${GREEN}   ✓ .env appears to have real configuration${NC}"
            return 0
        fi
    else
        return 1
    fi
}

# Function to fix .env file
fix_env_file() {
    print_section "🔧 Fixing .env file / إصلاح ملف .env"
    
    if [ ! -f ".env.example" ]; then
        echo -e "${RED}❌ Cannot create .env: .env.example not found${NC}"
        return 1
    fi
    
    if [ "$CHECK_ONLY" = true ]; then
        echo -e "${YELLOW}   [CHECK-ONLY] Would create .env from .env.example${NC}"
        return 0
    fi
    
    # Backup existing .env if it exists
    if [ -f ".env" ]; then
        backup_file=".env.backup.$(date +%Y%m%d_%H%M%S)"
        echo -e "${BLUE}   📦 Backing up existing .env to $backup_file${NC}"
        cp .env "$backup_file"
    fi
    
    # Copy .env.example to .env
    echo -e "${BLUE}   📝 Creating .env from .env.example...${NC}"
    cp .env.example .env
    
    echo -e "${GREEN}   ✅ Created .env file${NC}"
    echo ""
    echo -e "${BOLD}${YELLOW}⚠️  IMPORTANT ACTION REQUIRED:${NC}"
    echo -e "${YELLOW}   You must add your API key to .env file:${NC}"
    echo ""
    echo -e "${CYAN}   1. Get your API key from: https://openrouter.ai/keys${NC}"
    echo -e "${CYAN}   2. Open .env file: nano .env${NC}"
    echo -e "${CYAN}   3. Find line: OPENROUTER_API_KEY=sk-or-v1-xxx...${NC}"
    echo -e "${CYAN}   4. Replace with your real key: OPENROUTER_API_KEY=sk-or-v1-YOUR-KEY${NC}"
    echo -e "${CYAN}   5. Save and exit (Ctrl+O, Enter, Ctrl+X)${NC}"
    echo ""
    echo -e "${YELLOW}   عليك إضافة مفتاح API إلى ملف .env:${NC}"
    echo -e "${CYAN}   1. احصل على المفتاح من: https://openrouter.ai/keys${NC}"
    echo -e "${CYAN}   2. افتح .env: nano .env${NC}"
    echo -e "${CYAN}   3. استبدل المفتاح التجريبي بمفتاحك الحقيقي${NC}"
    echo -e "${CYAN}   4. احفظ واخرج${NC}"
    echo ""
    
    return 0
}

# Function to check API keys
check_api_keys() {
    print_section "2️⃣ Checking API Keys / فحص مفاتيح API"
    
    if [ ! -f ".env" ]; then
        echo -e "${RED}❌ Cannot check: .env file not found${NC}"
        return 1
    fi
    
    # Check OPENROUTER_API_KEY
    local openrouter_key=$(grep "^OPENROUTER_API_KEY=" .env 2>/dev/null | cut -d'=' -f2)
    local openai_key=$(grep "^OPENAI_API_KEY=" .env 2>/dev/null | cut -d'=' -f2)
    
    local has_valid_key=false
    
    if [[ ! -z "$openrouter_key" && "$openrouter_key" != "sk-or-v1-xxx"* ]]; then
        echo -e "${GREEN}✅ OPENROUTER_API_KEY: Configured${NC}"
        has_valid_key=true
    else
