# app/services/api_gateway_deployment.py
# ======================================================================================
# ==        API GATEWAY DEPLOYMENT STRATEGIES (v1.0 - ADVANCED EDITION)            ==
# ======================================================================================
# PRIME DIRECTIVE:
#   إدارة النسخ والتجارب - Version and experiment management
#   ✨ المميزات:
#   - A/B testing support
#   - Canary deployments
#   - Blue-Green deployments
#   - Feature flags
#   - Traffic splitting
#   - Rollback capabilities

import hashlib
import random
import threading
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum
from typing import Any

from flask import current_app

# ======================================================================================
# ENUMERATIONS
# ======================================================================================


class DeploymentStrategy(Enum):
    """Deployment strategies"""

    IMMEDIATE = "immediate"
    CANARY = "canary"
    BLUE_GREEN = "blue_green"
    ROLLING = "rolling"
    AB_TEST = "ab_test"


class FeatureFlagStatus(Enum):
    """Feature flag statuses"""

    ENABLED = "enabled"
    DISABLED = "disabled"
    CANARY = "canary"
    PERCENTAGE = "percentage"


# ======================================================================================
# DATA STRUCTURES
# ======================================================================================


@dataclass
class ModelVersion:
    """AI Model version metadata"""

    version_id: str
    model_name: str
    version_number: str
    created_at: datetime
    status: str  # 'active', 'canary', 'deprecated', 'sunset'
    traffic_weight: float = 0.0  # 0.0 to 1.0
    performance_metrics: dict[str, float] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class ABTestExperiment:
    """A/B test experiment configuration"""

    experiment_id: str
    name: str
    description: str
    variant_a: str  # Version A identifier
    variant_b: str  # Version B identifier
    traffic_split: float = 0.5  # 0.0 to 1.0 for variant B
    started_at: datetime | None = None
    ended_at: datetime | None = None
    metrics: dict[str, Any] = field(default_factory=dict)
    winning_variant: str | None = None


@dataclass
class CanaryDeployment:
    """Canary deployment configuration"""

    deployment_id: str
    service_id: str
    canary_version: str
    stable_version: str
    canary_traffic_percent: float = 10.0  # Start with 10%
    increment_percent: float = 10.0
    increment_interval_minutes: int = 15
    success_threshold: float = 0.95  # 95% success rate required
    started_at: datetime | None = None
    current_stage: str = "initial"
    metrics: dict[str, Any] = field(default_factory=dict)


@dataclass
class FeatureFlag:
    """Feature flag configuration"""

    flag_id: str
    name: str
    description: str
    status: FeatureFlagStatus
    enabled_percentage: float = 0.0  # For percentage rollout
    enabled_users: list[str] = field(default_factory=list)  # Specific users
    enabled_groups: list[str] = field(default_factory=list)  # Specific groups
    metadata: dict[str, Any] = field(default_factory=dict)


# ======================================================================================
# AB TESTING SERVICE
# ======================================================================================


class ABTestingService:
    """
    خدمة اختبار A/B - A/B testing service

    Features:
    - Traffic splitting between variants
    - Statistical significance testing
    - Automatic winner selection
    - User assignment consistency
    """

    def __init__(self):
        self.experiments: dict[str, ABTestExperiment] = {}
        self.user_assignments: dict[str, dict[str, str]] = defaultdict(
            dict
        )  # user_id -> {exp_id: variant}
        self.lock = threading.RLock()

    def create_experiment(self, experiment: ABTestExperiment) -> bool:
        """Create new A/B test experiment"""
        with self.lock:
            if experiment.experiment_id in self.experiments:
                return False

            experiment.started_at = datetime.now(UTC)
            self.experiments[experiment.experiment_id] = experiment

            current_app.logger.info(f"Created A/B test: {experiment.name}")
            return True

    def assign_variant(self, experiment_id: str, user_id: str) -> str | None:
        """
        Assign user to a variant

        Returns:
            Variant identifier (variant_a or variant_b)
        """
        with self.lock:
            experiment = self.experiments.get(experiment_id)
            if not experiment:
                return None

            # Check if user already assigned
            if experiment_id in self.user_assignments[user_id]:
                return self.user_assignments[user_id][experiment_id]

            # Assign based on traffic split - MD5 used ONLY for consistent user assignment, NOT for security (usedforsecurity=False)
            hash_input = f"{user_id}:{experiment_id}"
            hash_value = int(
                hashlib.md5(hash_input.encode(), usedforsecurity=False).hexdigest(), 16
            )  # nosec B324
            variant = (
                experiment.variant_b
                if (hash_value % 100) / 100.0 < experiment.traffic_split
                else experiment.variant_a
            )

            # Store assignment
            self.user_assignments[user_id][experiment_id] = variant

            # Update metrics
            variant_key = (
                "variant_b_assignments"
                if variant == experiment.variant_b
                else "variant_a_assignments"
            )
            experiment.metrics[variant_key] = experiment.metrics.get(variant_key, 0) + 1

            return variant

    def record_outcome(self, experiment_id: str, user_id: str, metric_name: str, value: float):
        """Record experiment outcome metric"""
        with self.lock:
            experiment = self.experiments.get(experiment_id)
            if not experiment:
                return

            variant = self.user_assignments[user_id].get(experiment_id)
            if not variant:
                return
