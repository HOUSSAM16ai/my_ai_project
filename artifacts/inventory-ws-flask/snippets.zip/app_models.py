# ======================================================================================
#  COGNIFORGE DOMAIN MODELS  v14.1  • "SUPERHUMAN ADMIN CHAT + OVERMIND CORE"       #
# ======================================================================================
#  PURPOSE (الغرض):
#    نموذج نطاق (Domain Model) نقي ومركّز حصرياً على نظام Overmind:
#      - إزالة جميع الجداول القديمة غير المتعلقة بـ Overmind
#      - إزالة جداول التعليم القديمة (subjects, lessons, exercises, submissions)
#      - إزالة جداول الأدمن القديمة (admin_conversations, admin_messages)
#      - إزالة جدول task_dependencies المساعد (نستخدم depends_on_json بدلاً منه)
#
#  WHAT'S NEW in v14.1 (مقارنة بـ v14.0):
#    - 🔥 RESTORED: AdminConversation & AdminMessage models with SUPERHUMAN design
#    - 💪 ENHANCED: Advanced metadata, analytics, and indexing capabilities
#    - 🚀 SUPERIOR: Professional-grade conversation tracking surpassing tech giants
#    - 📊 METRICS: Token usage, latency, cost tracking, and conversation analytics
#    - 🔍 SEARCH: Content hashing, semantic embeddings support, and advanced indexing
#    - ⚡ PERFORMANCE: Optimized JSONB fields and composite indexes for blazing speed
#
#  CORE MODELS (النماذج الأساسية النقية):
#    ✅ User               - حسابات المستخدمين
#    ✅ AdminConversation  - محادثات الأدمن (نظام تسجيل خارق)
#    ✅ AdminMessage       - رسائل محادثات الأدمن (تتبع متقدم)
#    ✅ Mission            - المهام الرئيسية
#    ✅ MissionPlan        - خطط تنفيذ المهام
#    ✅ Task               - المهام الفرعية (باستخدام depends_on_json للتبعيات)
#    ✅ MissionEvent       - سجل أحداث المهام
#
#  REMOVED LEGACY SYSTEMS:
#    ❌ Education Kingdom (subjects, lessons, exercises, submissions)
#    ❌ task_dependencies helper table (replaced by depends_on_json)
#
#  SEMANTIC MISSION EVENTS (الإصدار التحليلي):
#      MISSION_UPDATED, RISK_SUMMARY, ARCHITECTURE_CLASSIFIED,
#      MISSION_COMPLETED, MISSION_FAILED, FINALIZED
#
#  PRE-EXISTING FEATURES:
#    - result_meta_json قناة وصفية للنتائج
#    - تحويل الطوابع الزمنية المرنة (coerce_datetime)
#    - منطق إعادة المحاولة (retry scheduling)
#    - حساب مدة متسق (compute_duration)
#    - فهارس متكررة الاستعلام
#    - تهشير المحتوى (hash_content)
#    - إحصاءات مشتقة على Mission (success_ratio ...)
#    - واجهات موحّدة (update_mission_status / log_mission_event / finalize_task)
#    - JSONB_or_JSON تجريد PostgreSQL/SQLite
#
#  MIGRATION HISTORY (ذات صلة):
#    - 0fe9bd3b1f3c : Genesis schema (with legacy tables)
#    - 0b5107e8283d : إضافة result_meta_json لِـ Task
#    - 20250902_event_type_text_and_index_super : تحويل event_type إلى TEXT
#    - c670e137ea84 : إضافة admin chat system (legacy)
#    - 20250103_purify_db : 🔥 PURIFICATION - إزالة جميع الجداول القديمة
#
#  NOTE (مهم):
#    - استخدام db.Enum(..., native_enum=False) يعني تخزين القيم كسلاسل (VARCHAR/TEXT)
#    - Task.depends_on_json يحتوي على قائمة task_keys للتبعيات (أبسط وأكثر مرونة)
#    - لا توجد علاقات many-to-many معقدة بعد الآن
#
#  TRANSACTION POLICY:
#    - هذا الملف لا يقوم بالـ commit. مسؤولية إدارة المعاملات تقع على الطبقات العليا
#      (الخدمات / orchestrator).
#
# ======================================================================================

from __future__ import annotations

# Version information for conftest.py version checking
__version__ = "14.1.0"

import enum
import hashlib
from datetime import UTC, datetime, timedelta
from typing import Any

# from flask_login import UserMixin # Removed Flask Dependency
from sqlalchemy import (
    JSON as SAJSON,
    DateTime,
    String,
    Integer,
    Boolean,
    Text,
    Float,
    Numeric,
    ForeignKey,
    Index,
    TypeDecorator,
    UniqueConstraint,
    event,
    func,
    text,
    Enum,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

# from app import db, login_manager # Removed Flask Dependency
from .extensions import db  # Corrected import for SQLAlchemy

# ======================================================================================
# CONFIG / CONSTANTS (اختياري — يعكس قيد الهجرة إذا كان مفعلاً)
# ======================================================================================

EVENT_TYPE_MAX_LEN = 128  # مطابقة للهجرة (إن وُجد CHECK). مرجع فقط—العمود TEXT.

# ======================================================================================
# UTILITIES
# ======================================================================================


class JSONB_or_JSON(TypeDecorator):
    """
    استخدام JSONB في PostgreSQL وإلا JSON قياسي (JSON).
    يحافظ على واجهة موحّدة للبيئات المختلفة.
    """

    impl = SAJSON
    cache_ok = True

    def load_dialect_impl(self, dialect):
        return (
            dialect.type_descriptor(JSONB())
            if dialect.name == "postgresql"
            else dialect.type_descriptor(SAJSON())
        )


def utc_now() -> datetime:
    return datetime.now(UTC)


def hash_content(content: str) -> str:
    return hashlib.sha256(content.encode("utf-8")).hexdigest()


def coerce_datetime(value: Any) -> datetime | None:
    """
    تحويل مرن إلى datetime بتوقيت UTC.
    يقبل: datetime / int أو float (Epoch) / string (مجموعة صيغ) / وإلا None.
    """
    if value is None:
        return None
    if isinstance(value, datetime):
        return value.astimezone(UTC) if value.tzinfo else value.replace(tzinfo=UTC)
    if isinstance(value, int | float):
        try:
            return datetime.fromtimestamp(float(value), tz=UTC)
        except Exception:
            return None
    if isinstance(value, str):
        fmts = (
            "%Y-%m-%d %H:%M:%S.%f%z",
            "%Y-%m-%d %H:%M:%S.%f",
            "%Y-%m-%d %H:%M:%S%z",
            "%Y-%m-%d %H:%M:%S",
            "%Y-%m-%dT%H:%M:%S.%f%z",
            "%Y-%m-%dT%H:%M:%S.%f",
            "%Y-%m-%dT%H:%M:%S%z",
            "%Y-%m-%dT%H:%M:%S",
        )
        for fmt in fmts:
            try:
                dt = datetime.strptime(value, fmt)
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=UTC)
                return dt.astimezone(UTC)
            except Exception:
                continue
        try:
            dt = datetime.fromisoformat(value)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=UTC)
            return dt.astimezone(UTC)
        except Exception:
            return None
    return None


# ======================================================================================
# ENUMS
# ======================================================================================


class MessageRole(enum.Enum):
    USER = "user"
    ASSISTANT = "assistant"
    TOOL = "tool"
    SYSTEM = "system"


class MissionStatus(enum.Enum):
    PENDING = "PENDING"
    PLANNING = "PLANNING"
    PLANNED = "PLANNED"
    RUNNING = "RUNNING"
    ADAPTING = "ADAPTING"
    SUCCESS = "SUCCESS"
    FAILED = "FAILED"
    CANCELED = "CANCELED"

