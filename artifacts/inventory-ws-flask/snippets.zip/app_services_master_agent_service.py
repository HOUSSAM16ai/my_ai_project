# app/services/master_agent_service.py
# =================================================================================================
# OVERMIND MASTER ORCHESTRATOR – LEVEL‑4 DEEP SCAN / HYPER EXECUTION CORE
# Version : 10.3.0-l4-pro
# Codename: "AURORA HYPERFLOW PRIME / STRUCTURAL-BOOST / SAFE-ADAPT / TELEMETRY-LITE"
# Status  : Production / Hardened / Deterministic + Adaptive / Observability Enhanced
# Author  : System Orchestrator (Hyper Refined Edition)
# =================================================================================================
# EN OVERVIEW
#   Drives end‑to‑end mission lifecycle:
#     1. Mission creation (natural language objective → persisted Mission).
#     2. Multi-planner candidate generation & deterministic scoring.
#     3. Guarded, canonicalized task execution (tool normalization, autofill, interpolation).
#     4. Optional structural diff augmentation for write_file tasks (bounded).
#     5. Structural index (deep_context) injection for planner signal boosting.
#     6. Stall detection windows + bounded runtime termination.
#     7. Adaptive replanning with controlled cycles & hash convergence guard.
#     8. Semantic event emission (CREATED, PLAN_SELECTED, EXECUTION_STARTED, TASK_*,
#        RISK_SUMMARY, ARCHITECTURE_CLASSIFIED, REPLAN_TRIGGERED, REPLAN_APPLIED,
#        MISSION_COMPLETED, MISSION_FAILED, FINALIZED).
#     9. Light telemetry: execution timing, planner failures, tool success map.
#
# AR OVERVIEW (ملخص عربي)
#   ينفّذ دورة حياة المهمة كاملة:
#     - إنشاء مهمة من هدف نصي.
#     - إنتاج واختيار خطة عبر عدة مخططين.
#     - تنفيذ مهام بأدوات مؤمنة (تطبيع + تعبئة + استبدال قوالب).
#     - دعم فهرس بنيوي عميق اختياري لرفع دقة الاختيار.
#     - إعادة تخطيط تكيفية مضبوطة بعد الإخفاق.
#     - بث أحداث دلالية كاملة وتحليلات خفيفة.
#
# NEW vs 10.2.x
#   + Proper deep_context passing (carried forward).
#   + MAX_PLANNER_CANDIDATES limit (env: OVERMIND_MAX_PLANNER_CANDIDATES).
#   + Safe commit / refresh helpers (_safe_commit / _safe_refresh).
#   + Planner failure ring buffer (bounded).
#   + Tool success metrics aggregation.
#   + Adaptive convergence guard (plan content hash check).
#   + Optional reuse of deep_context in adaptive replan (OVERMIND_ADAPTIVE_DEEP_CONTEXT=1).
#   + Enhanced diff augmentation (ratio_class).
#   + iso_ts on selected logs & events.
#   + Docstrings for public APIs.
#
# SAFETY & CONTRACTS
#   - No DB schema changes.
#   - All terminal endings produce FINALIZED event.
#   - Features degrade gracefully if deep index or diff is unavailable.
#
# EXTENSIBILITY
#   - ToolPolicyEngine.authorize(...) for RBAC / quotas.
#   - VerificationService.verify(...) for domain validation.
#   - _augment_with_diff(...) future richer semantic/AST diff.
#   - _build_deep_index_context(...) future embeddings / advanced scoring.
# =================================================================================================

from __future__ import annotations

import difflib
import hashlib
import json
import os
import random
import re
import threading
import time
from contextlib import contextmanager, suppress
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from typing import Any

from flask import current_app, has_app_context
from sqlalchemy import exists, func, select
from sqlalchemy.orm import joinedload

from app import db
from app.models import (
    Mission,
    MissionEventType,
    MissionPlan,
    MissionStatus,
    PlanStatus,
    Task,
    TaskStatus,
    User,
    log_mission_event,
    update_mission_status,
    utc_now,
)

# Factory returns planner INSTANCES (legacy shim updated there)
from app.overmind.planning.factory import get_all_planners
from app.overmind.planning.schemas import MissionPlanSchema

# -------------------------------------------------------------------------------------------------
# Planner base errors (graceful fallback)
# -------------------------------------------------------------------------------------------------
try:
    from app.overmind.planning.base_planner import PlannerError, PlanValidationError
except Exception:  # pragma: no cover

    class PlannerError(Exception): ...

    class PlanValidationError(Exception): ...


# -------------------------------------------------------------------------------------------------
# Optional generation backend
# -------------------------------------------------------------------------------------------------
try:
    from app.services import generation_service as maestro
except Exception:  # pragma: no cover

    class maestro:  # type: ignore
        @staticmethod
        def execute_task(task: Task):
            task.result_text = f"[MOCK EXECUTION] {task.description or ''}"
            task.status = TaskStatus.SUCCESS
            task.finished_at = utc_now()
            db.session.commit()


# -------------------------------------------------------------------------------------------------
# Agent tools registry
# -------------------------------------------------------------------------------------------------
try:
    from app.services import agent_tools
except Exception:  # pragma: no cover
    agent_tools = None
# -------------------------------------------------------------------------------------------------
# Optional Deep Index
# -------------------------------------------------------------------------------------------------
try:
    from app.overmind.planning.deep_indexer import build_index, summarize_for_prompt
except Exception:  # pragma: no cover
    build_index = None
    summarize_for_prompt = None


# =================================================================================================
# Policy & Verification Hooks
# =================================================================================================
class ToolPolicyEngine:
    def authorize(self, tool_name: str, mission: Mission, task: Task) -> bool:
        return True


tool_policy_engine = ToolPolicyEngine()


class VerificationService:
    def verify(self, task: Task) -> bool:
        return True


verification_service = VerificationService()


# =================================================================================================
# Metrics Stubs (integrate externally later)
# =================================================================================================
def increment_counter(name: str, labels: dict[str, str] | None = None):  # pragma: no cover
    pass


def observe_histogram(
    name: str, value: float, labels: dict[str, str] | None = None
):  # pragma: no cover
    pass


def set_gauge(name: str, value: float, labels: dict[str, str] | None = None):  # pragma: no cover
    pass


# =================================================================================================
# Configuration
# =================================================================================================
OVERMIND_VERSION = "10.3.0-l4-pro"

DEFAULT_MAX_TASK_ATTEMPTS = 3
ADAPTIVE_MAX_CYCLES = int(os.getenv("ADAPTIVE_MAX_CYCLES", "3"))
REPLAN_FAILURE_THRESHOLD = int(os.getenv("REPLAN_FAILURE_THRESHOLD", "2"))
MAX_PLANNER_CANDIDATES = int(os.getenv("OVERMIND_MAX_PLANNER_CANDIDATES", "32"))
ADAPTIVE_USE_DEEP_CONTEXT = os.getenv("OVERMIND_ADAPTIVE_DEEP_CONTEXT", "0") == "1"

EXECUTION_STRATEGY = "topological"
EXECUTION_PARALLELISM_MODE = os.getenv("OVERMIND_EXEC_PARALLEL", "MULTI").upper()
TOPO_MAX_PARALLEL = 6

TASK_EXECUTION_HARD_TIMEOUT_SECONDS = 180
MAX_TOTAL_RUNTIME_SECONDS = 7200
TASK_RETRY_BACKOFF_BASE = 2.0
TASK_RETRY_BACKOFF_JITTER = 0.5

DEFAULT_POLL_INTERVAL = float(os.getenv("OVERMIND_POLL_INTERVAL_SECONDS", "0.18"))
MAX_LIFECYCLE_TICKS = int(os.getenv("OVERMIND_MAX_LIFECYCLE_TICKS", "1500"))

STALL_DETECTION_WINDOW = 12
STALL_NO_PROGRESS_THRESHOLD = 0
VERBOSE_DEBUG = os.getenv("OVERMIND_LOG_DEBUG", "0") == "1"
